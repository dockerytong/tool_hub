# FTICR-shinny Project - QWEN Context

## Project Overview

This is an R Shiny application for FT-ICR MS (Fourier Transform Ion Cyclotron Resonance Mass Spectrometry) DOM (Dissolved Organic Matter) data analysis. The application provides comprehensive data processing, visualization, and statistical analysis capabilities specifically designed for environmental chemistry and mass spectrometry data analysis.

**Project Type:** R Shiny Web Application  
**Language:** R  
**Domain:** Environmental Chemistry & Mass Spectrometry Analysis

## Architecture

### Directory Structure
```
FTICR-shinny/
├── app.R                    # Main application entry point
├── global.R                 # Global configuration and dependency management
├── R/                       # Modules and functions directory
│   ├── mod_*.R             # Shiny modules (UI + Server logic)
│   ├── fct_*.R             # Function files
│   └── utils_helpers.R     # Utility functions
├── test_all_modules.R      # Module testing
├── test_refactoring.R      # Refactoring tests
├── CODE_INCONSISTENCY_ANALYSIS.md  # Code analysis report
├── DEVELOPMENT_DOCUMENTATION.md    # Development guide
├── REFACTORING_SUMMARY.md          # Refactoring summary
└── 2025-12-08-长代码版本.zip    # Backup archive
```

### Core Architecture
- **Modular Design:** Each analytical function is implemented as a separate Shiny module
- **Reactive Data Flow:** Uses global `reactiveValues` (rv) for data sharing across modules
- **Standardized Patterns:** Follows consistent naming conventions and error handling

## Key Modules

### Data Processing Modules
1. **`mod_data_upload.R`** - Data upload, TIC normalization, background subtraction
2. **`mod_vk_plot.R`** - Van Krevelen diagram visualization
3. **`mod_composition.R`** - Elemental composition analysis
4. **`mod_diversity.R`** - Alpha diversity calculations
5. **`mod_ordination.R`** - PCoA/NMDS ordination analysis

### Analysis Modules
6. **`mod_molecular.R`** - Molecular characteristics analysis
7. **`mod_properties.R`** - Chemical properties prediction
8. **`mod_gibbs.R`** - Gibbs free energy calculations
9. **`mod_lability.R`** - Biological lability classification
10. **`mod_cram.R`** - CRAM (Carboxylic-rich Alicyclic Molecules) identification
11. **`mod_diff.R`** - Differential analysis
12. **`mod_stat_diff.R`** - Advanced statistical differential analysis
13. **`mod_upset.R`** - Set relationship visualization
14. **`mod_correlation.R`** - Environmental factor correlation analysis
15. **`mod_transformation.R`** - Compound transformation analysis
16. **`mod_ml.R`** - Machine learning module
17. **`mod_export.R`** - Data export functionality

### Function Files
- **`fct_chemistry.R`** - Chemical calculations, molecular indices
- **`fct_ordination.R`** - Ordination analysis functions
- **`fct_plots.R`** - Plotting functions
- **`fct_network.R`** - Network analysis functions
- **`fct_plots_network.R`** - Network visualization functions
- **`fct_ml.R`** - Machine learning functions
- **`utils_helpers.R`** - General utility functions

## Dependencies

### Core Dependencies
- `shiny` - Web application framework
- `tidyverse` - Data manipulation and analysis
- `data.table` - High-performance data processing
- `vegan` - Ecological statistics analysis
- `ggplot2` - Data visualization
- `plotly` - Interactive charts

### Specialized Packages
- `ComplexUpset` - Set visualization
- `corrplot` - Correlation matrix plots
- `cowplot` - Figure composition
- `ggrepel` - Label overlap handling
- `readxl` - Excel file reading

## Development Conventions

### Naming Conventions
- Module files: `mod_功能名称.R` (e.g., `mod_data_upload.R`)
- Function files: `fct_功能类别.R` (e.g., `fct_chemistry.R`)
- Functions: Descriptive names with verbs
- Module functions: `mod_moduleName_ui()` and `mod_moduleName_server()`

### Code Structure
- **Naming Space Handling:** Use `session$ns` directly instead of redefining as `ns`
- **Reactive Logic:** Use `reactive()` consistently instead of mixing with `reactiveVal()`
- **Error Handling:** Standardized with validation functions
- **Function Calls:** Consistent parameters for common functions like `render_plot_container()`

### Standardized Components
- `validate_sufficient_data()` - Data sufficiency validation
- `filter_sample_data()` - Standardized data filtering
- `ui_sample_selector()` - Consistent sample selection UI
- `ui_analysis_info_panel()` - Standardized information panels
- `generate_filename()` - Consistent file naming

## Building and Running

### Requirements
- R >= 4.0.0
- All dependencies listed in `global.R` installed

### Running the Application
```r
# From the project directory
R
> library(shiny)
> runApp(".")

# Or directly from command line
Rscript -e "shiny::runApp('.', launch.browser=TRUE)"
```

### Testing
The project includes comprehensive testing scripts:
- `test_all_modules.R` - Validates all module refactoring
- Standardized test functions for data validation, filtering, and naming

## Key Constants and Data

### Chemical Classifications
- **VK Zones:** Defined regions for Van Krevelen diagram categories (Lipid-like, Protein-like, etc.)
- **Color Schemes:** Consistent color mapping for chemical categories
- **Transformations:** Library of common chemical transformations with masses

### Global Reactive Values (rv)
```r
rv <- reactiveValues(
    file_info = NULL,        # File information
    sample_names = NULL,     # Sample names
    processed_data = NULL,   # Processed data
    alpha_div = NULL,        # Alpha diversity
    pcoa_result = NULL,      # PCoA results
    wa_data = NULL,          # Weighted average data
    lability_result = NULL,  # Lability analysis results
    cram_data = NULL,        # CRAM data
    diff_result = NULL,      # Differential analysis results
    env_data = NULL,         # Environmental data
    cor_result = NULL,       # Correlation analysis results
    export_data = NULL       # Export data
)
```

## Recent Improvements

### Refactoring Achievements
- Fixed namespace inconsistencies across all modules
- Standardized reactive logic using `reactive()` pattern
- Created reusable utility functions
- Improved error handling and validation
- Reduced code duplication by ~60%

### Code Quality Metrics
- Function call consistency: 100%
- Namespacing standardization: 100%
- Error handling coverage: 100%
- Code reusability significantly improved

## Usage Context

This application is designed for researchers in environmental chemistry to analyze complex FT-ICR MS data. It provides tools for:
- Visualizing molecular composition in Van Krevelen diagrams
- Assessing diversity and lability of organic compounds
- Performing statistical comparisons between samples
- Identifying CRAM (carboxylic-rich alicyclic molecules) compounds
- Analyzing correlations between chemical properties and environmental factors
- Creating transformation networks between compounds
- Exporting results in various formats

The application handles large datasets efficiently and provides an intuitive interface for complex mass spectrometry data analysis.