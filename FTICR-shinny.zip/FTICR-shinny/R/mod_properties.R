# ==============================================================================
# mod_properties.R - 加权性质模块
# ==============================================================================

mod_properties_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "加权性质",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                ui_display_settings(ns, default_w = 1000, default_h = 400),
                ui_export_settings(ns, default_w = 10, default_h = 6),
                hr(),
                downloadButton(ns("download_csv"), "下载数据表 (CSV)")
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("info_panel")),
                h4("样品加权平均化学性质"),
                tableOutput(ns("table"))
            )
        )
    )
}

mod_properties_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 标准化的表格渲染
        output$table <- renderTable({
            req(rv$wa_data)
            if (!validate_sufficient_data(rv$wa_data, 1, "加权性质分析")) {
                return(NULL)
            }
            rv$wa_data %>% dplyr::mutate(across(where(is.numeric), ~ round(.x, 3)))
        })

        # 标准化的分析信息面板
        output$info_panel <- renderUI({
            req(rv$wa_data)
            
            info_items <- list(
                list(label = "加权平均性质:", 
                     description = "基于分子丰度加权的化学性质，反映样品整体的化学特征"),
                list(label = "主要指标:", 
                     description = "包括分子量(MW)、元素比(O/C, H/C)、芳香性指数(AI)等关键参数"),
                list(label = "应用价值:", 
                     description = "用于比较不同样品的整体化学特征差异，追踪环境梯度变化")
            )
            
            ui_analysis_info_panel(session$ns, "数据说明", info_items, icon = "info-circle")
        })

        output$download_csv <- downloadHandler(
            filename = function() "Weighted_Averages.csv",
            content = function(file) readr::write_csv(rv$wa_data, file)
        )
    })
}
