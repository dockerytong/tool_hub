# ==============================================================================
# mod_correlation.R - 环境相关性模块 (修复版)
# ==============================================================================

mod_correlation_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "环境相关性",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                radioButtons(ns("input_mode"), "数据输入方式：",
                    choices = c("上传文件" = "upload", "手动输入" = "manual"), selected = "upload"
                ),
                conditionalPanel(
                    condition = sprintf("input['%s'] == 'upload'", ns("input_mode")),
                    fileInput(ns("env_upload"), "上传环境因子数据", accept = c(".csv", ".xlsx", ".xls")),
                    helpText("第一列应为样品名")
                ),
                conditionalPanel(
                    condition = sprintf("input['%s'] == 'manual'", ns("input_mode")),
                    uiOutput(ns("manual_inputs")),
                    actionButton(ns("btn_add_var"), "添加变量", icon = icon("plus"), class = "btn-sm"),
                    actionButton(ns("btn_apply"), "应用数据", icon = icon("check"), class = "btn-success btn-sm")
                ),
                hr(),
                selectInput(ns("method"), "相关性方法：", choices = c("spearman", "pearson"), selected = "spearman"),
                checkboxInput(ns("show_coef"), "显示相关系数", value = TRUE),
                actionButton(ns("btn_run"), "计算相关性", class = "btn-info", icon = icon("chart-line")),
                ui_display_settings(ns, default_w = 1000, default_h = 800), # 新增
                ui_export_settings(ns, default_w = 10, default_h = 8)
            ),
            mainPanel(
                width = 9,
                h5("环境因子数据预览"),
                tableOutput(ns("env_preview")),
                hr(),
                uiOutput(ns("plot_container")),

                # ---- 解释文本 ----
                div(
                    class = "alert alert-info", style = "margin-top: 20px;",
                    h5(icon("info-circle"), "分析说明："),
                    p("该模块计算环境因子与 DOM 核心指标（如多样性、加权平均分子量、CRAM 比例等）之间的相关性。"),
                    tags$ul(
                        tags$li(strong("Spearman:"), " 秩相关，适用于非正态分布数据（推荐）。"),
                        tags$li(strong("Pearson:"), " 线性相关，要求数据符合正态分布。"),
                        tags$li("红色代表正相关，蓝色代表负相关。星号代表显著性水平 (* p<0.05)。")
                    )
                )
            )
        )
    )
}

mod_correlation_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        ns <- session$ns
        env_var_count <- reactiveVal(1)

        # 上传文件 (这里是之前出错的地方)
        observeEvent(input$env_upload, {
            req(input$env_upload)
            rv$env_data <- read_env_data(input$env_upload$datapath)
        })

        # 手动输入逻辑
        observeEvent(input$btn_add_var, {
            env_var_count(env_var_count() + 1)
        })

        output$manual_inputs <- renderUI({
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            n_vars <- env_var_count()
            tagList(lapply(1:n_vars, function(i) {
                tagList(
                    textInput(ns(paste0("var_name_", i)), paste("变量", i, "名称："), value = paste0("Var", i)),
                    lapply(seq_along(samples), function(j) {
                        numericInput(ns(paste0("val_", i, "_", j)), paste0(samples[j], ":"), value = NA)
                    }), hr()
                )
            }))
        })

        observeEvent(input$btn_apply, {
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            n_vars <- env_var_count()
            env_df <- data.frame(Sample = samples)
            for (i in 1:n_vars) {
                var_name <- input[[paste0("var_name_", i)]]
                if (is.null(var_name) || var_name == "") var_name <- paste0("Var", i)
                values <- sapply(seq_along(samples), function(j) {
                    val <- input[[paste0("val_", i, "_", j)]]
                    if (is.null(val) || is.na(val)) NA else as.numeric(val)
                })
                env_df[[var_name]] <- values
            }
            rv$env_data <- env_df
            showNotification("环境因子数据已应用！", type = "message")
        })

        output$env_preview <- renderTable({
            req(rv$env_data)
            rv$env_data %>% dplyr::mutate(across(where(is.numeric), ~ round(.x, 3)))
        })

        # 计算相关性
        observeEvent(input$btn_run, {
            req(rv$alpha_div, rv$wa_data, rv$lability_result, rv$cram_data, rv$env_data)
            withProgress(message = "计算相关性...", {
                merged <- merge_dom_env(rv$alpha_div, rv$wa_data, rv$lability_result, rv$cram_data, rv$env_data)
                rv$cor_result <- calculate_correlation(merged, method = input$method)
            })
        })

        plot_reactive <- reactive({
            req(rv$cor_result)
            plot_correlation_heatmap(rv$cor_result, show_coef = input$show_coef)
        })

        render_plot_container(output, session$ns, input)

        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        filename_base <- reactive({
            "Correlation"
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)
    })
}
