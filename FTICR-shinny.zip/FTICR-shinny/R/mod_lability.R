# ==============================================================================
# mod_lability.R - 活性指数模块 (完整版)
# ==============================================================================

mod_lability_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "活性指数",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                radioButtons(ns("plot_type"), "图类型：",
                    choices = c("组成堆叠" = "stack", "活性指数" = "index"),
                    selected = "stack"
                ),
                ui_display_settings(ns, default_w = 1000, default_h = 600),
                ui_export_settings(ns, default_w = 10, default_h = 6),
                hr(),
                downloadButton(ns("download_csv"), "下载数据表")
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),
                uiOutput(ns("info_panel"))
            )
        )
    )
}

mod_lability_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 标准化的响应式逻辑
        plot_reactive <- reactive({
            req(rv$lability_result)
            if (!validate_sufficient_data(rv$lability_result$detail, 1, "活性指数分析")) {
                return(NULL)
            }
            
            if (input$plot_type == "stack") {
                plot_lability_stack(rv$lability_result)
            } else {
                plot_lability_index(rv$lability_result)
            }
        })
        
        # 使用标准化的容器和绘图函数
        render_plot_container(output, session$ns, input)
        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        # 标准化的分析信息面板
        output$info_panel <- renderUI({
            req(rv$lability_result)
            
            info_items <- list(
                list(label = "Labile (活性):", 
                     description = "H/C > 1.5 且 O/C < 0.5。通常为脂类、蛋白质类，易被生物利用"),
                list(label = "Recalcitrant (惰性):", 
                     description = "AI_mod >= 0.5。通常为稠环芳烃、黑碳等，极难降解"),
                list(label = "Intermediate (中间态):", 
                     description = "介于两者之间，通常为木质素、单宁等"),
                list(label = "Lability Index:", 
                     description = "Labile / (Labile + Recalcitrant)。指数越高，DOM 整体生物活性越强")
            )
            
            ui_analysis_info_panel(session$ns, "分类标准", info_items, icon = "info-circle")
        })

        # 使用标准化的文件命名
        filename_base <- reactive({
            generate_filename("Lability", input$plot_type)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)

        output$download_csv <- downloadHandler(
            filename = function() "Lability_Index.csv",
            content = function(file) readr::write_csv(rv$lability_result$index, file)
        )
    })
}
