# ==============================================================================
# mod_ordination.R - 综合排序分析模块 (完整版)
# ==============================================================================

mod_ordination_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "排序分析",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                h5("分析设置"),
                selectInput(ns("method"), "排序方法：",
                    choices = c(
                        "非约束: PCA (Hellinger)" = "pca",
                        "非约束: PCoA (MDS)" = "pcoa",
                        "非约束: NMDS" = "nmds",
                        "约束: RDA (Redundancy)" = "rda",
                        "约束: CCA (Canonical)" = "cca"
                    ), selected = "pca"
                ),
                conditionalPanel(
                    condition = "input.method == 'pcoa' || input.method == 'nmds'",
                    ns = ns,
                    selectInput(ns("dist_method"), "距离算法：",
                        choices = c("Bray-Curtis" = "bray", "Jaccard" = "jaccard", "Euclidean" = "euclidean"),
                        selected = "bray"
                    )
                ),
                conditionalPanel(
                    condition = "input.method == 'rda' || input.method == 'cca'",
                    ns = ns,
                    fileInput(ns("env_upload"), "上传环境因子 (CSV/Excel)", accept = c(".csv", ".xlsx")),
                    helpText("必选：用于约束排序。第一列为 Sample。")
                ),
                hr(),
                h5("分组设置 (用于绘图)"),
                radioButtons(ns("grp_mode"), "分组来源：", choices = c("上传文件" = "upload", "手动输入" = "manual")),
                conditionalPanel(
                    condition = "input.grp_mode == 'upload'", ns = ns,
                    fileInput(ns("meta_upload"), "上传分组表 (CSV)", accept = ".csv")
                ),
                conditionalPanel(
                    condition = "input.grp_mode == 'manual'", ns = ns,
                    div(
                        style = "max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 5px;",
                        uiOutput(ns("manual_grp_ui"))
                    ),
                    actionButton(ns("btn_apply_grp"), "应用分组", class = "btn-xs btn-success", style = "margin-top:5px;")
                ),
                hr(),
                checkboxInput(ns("show_ellipse"), "显示置信椭圆", value = FALSE),
                actionButton(ns("btn_run"), "开始分析", class = "btn-primary", icon = icon("play")),
                ui_display_settings(ns, default_w = 900, default_h = 600), # 新增
                ui_export_settings(ns, default_w = 7, default_h = 6)
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),
                hr(),
                fluidRow(
                    column(6, h5("环境因子预览"), tableOutput(ns("env_preview"))),
                    column(6, h5("分组预览"), tableOutput(ns("meta_preview")))
                ),

                # ---- 新增：解释文本 ----
                div(
                    class = "alert alert-info", style = "margin-top: 20px;",
                    h5(icon("info-circle"), "方法指南："),
                    tags$ul(
                        tags$li(strong("PCA (主成分分析):"), " 基于线性模型，适合短梯度数据。本模块自动对数据进行 Hellinger 转化以适应生态数据。"),
                        tags$li(strong("PCoA (主坐标分析):"), " 基于距离矩阵（如 Bray-Curtis），最灵活，适合各种类型的生态数据。"),
                        tags$li(strong("NMDS (非度量多维尺度分析):"), " 非参数方法，基于秩次，适合非线性数据。关注 Stress 值 (<0.2 可用)。"),
                        tags$li(strong("RDA (冗余分析):"), " PCA 的约束版本。寻找能被环境因子解释的变异。箭头代表环境因子，箭头越长、与轴夹角越小，相关性越强。"),
                        tags$li(strong("CCA (典范对应分析):"), " 基于单峰模型。假设物种对环境呈钟形响应。")
                    )
                )
            )
        )
    )
}

mod_ordination_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        ns <- session$ns

        meta_data <- reactiveVal(NULL)
        env_data <- reactiveVal(NULL)
        ord_res <- reactiveVal(NULL)

        # 环境因子处理
        observeEvent(input$env_upload, {
            req(input$env_upload)
            df <- read_env_data(input$env_upload$datapath)
            env_data(df)
        })
        output$env_preview <- renderTable({
            req(env_data())
            head(env_data(), 5)
        })

        # 分组处理
        observeEvent(input$meta_upload, {
            req(input$meta_upload)
            tryCatch(
                {
                    df <- readr::read_csv(input$meta_upload$datapath, show_col_types = FALSE)
                    colnames(df)[1:2] <- c("Sample", "Group")
                    meta_data(df)
                },
                error = function(e) showNotification("分组读取失败", type = "error")
            )
        })

        output$manual_grp_ui <- renderUI({
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            lapply(seq_along(samples), function(i) {
                val <- if (!is.null(meta_data())) meta_data()$Group[meta_data()$Sample == samples[i]][1] else "Group1"
                if (is.na(val)) val <- "Group1"
                textInput(ns(paste0("grp_", i)), samples[i], value = val)
            })
        })

        observeEvent(input$btn_apply_grp, {
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            grps <- sapply(seq_along(samples), function(i) input[[paste0("grp_", i)]])
            meta_data(data.frame(Sample = samples, Group = grps))
            showNotification("分组已应用", type = "message")
        })
        output$meta_preview <- renderTable({
            req(meta_data())
            head(meta_data(), 5)
        })

        # 执行分析
        observeEvent(input$btn_run, {
            req(rv$processed_data)
            if (input$method %in% c("rda", "cca") && is.null(env_data())) {
                showNotification("RDA/CCA 需要先上传环境因子数据！", type = "error")
                return()
            }
            withProgress(message = "正在计算排序...", {
                tryCatch(
                    {
                        res <- calculate_ordination(
                            rv$processed_data,
                            method = input$method,
                            dist_method = input$dist_method,
                            env_df = env_data()
                        )
                        ord_res(res)
                    },
                    error = function(e) {
                        showNotification(paste("计算失败:", e$message), type = "error")
                    }
                )
            })
        })

        plot_reactive <- reactive({
            req(ord_res())
            plot_ordination(ord_res(), metadata = meta_data(), show_ellipse = input$show_ellipse)
        })

        render_plot_container(output, session$ns, input)

        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        filename_base <- reactive({
            paste0("Ordination_", input$method)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)
    })
}
