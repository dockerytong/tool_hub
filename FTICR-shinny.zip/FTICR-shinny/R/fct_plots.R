# ==============================================================================
# fct_plots.R - 绑图函数
# ==============================================================================

#' VK 图（单样品）
plot_vk <- function(df, sample_id, vk_zones = VK_ZONES, vk_colors = VK_COLORS) {
    plot_data <- df %>%
        dplyr::filter(Sample == sample_id, Abundance > 0) %>%
        dplyr::mutate(alpha_val = scales::rescale(Abundance, to = c(0.3, 0.9)))

    ggplot2::ggplot(plot_data, ggplot2::aes(x = OC, y = HC)) +
        ggplot2::geom_point(ggplot2::aes(color = Category, alpha = alpha_val), size = 1.2) +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_alpha_identity() +
        ggplot2::scale_x_continuous(limits = c(0, 1.2), expand = c(0.02, 0)) +
        ggplot2::scale_y_continuous(limits = c(0, 2.5), expand = c(0.02, 0)) +
        ggplot2::geom_rect(
            data = vk_zones, ggplot2::aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            inherit.aes = FALSE, fill = NA, color = "gray40", linetype = "dashed", linewidth = 0.3
        ) +
        ggplot2::geom_text(
            data = vk_zones %>% dplyr::mutate(label_x = ifelse(xmin == 0, 0.03, (xmin + xmax) / 2), label_y = (ymin + ymax) / 2),
            ggplot2::aes(x = label_x, y = label_y, label = Category), inherit.aes = FALSE, size = 2.8, fontface = "italic", hjust = 0, color = "gray30"
        ) +
        ggplot2::labs(title = sample_id, x = "O/C", y = "H/C") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(legend.position = "none", plot.title = ggplot2::element_text(hjust = 0.5))
}

#' VK 分面图
plot_vk_facet <- function(df, vk_zones = VK_ZONES, vk_colors = VK_COLORS, ncol = 3) {
    plot_data <- df %>% dplyr::filter(Abundance > 0)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = OC, y = HC, color = Category)) +
        ggplot2::geom_point(size = 0.5, alpha = 0.4) +
        ggplot2::geom_rect(
            data = vk_zones, ggplot2::aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            inherit.aes = FALSE, fill = NA, color = "gray50", linetype = "dashed", linewidth = 0.2
        ) +
        ggplot2::facet_wrap(~Sample, ncol = ncol) +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_x_continuous(limits = c(0, 1.2), expand = c(0.02, 0)) +
        ggplot2::scale_y_continuous(limits = c(0, 2.5), expand = c(0.02, 0)) +
        ggplot2::labs(x = "O/C", y = "H/C", title = "Van Krevelen Diagram") +
        cowplot::theme_half_open(font_size = 10) +
        ggplot2::theme(legend.position = "right", strip.background = ggplot2::element_rect(fill = "grey95"))
}

#' 元素组成堆叠图
plot_elemental_stack <- function(df, elem_colors = ELEM_COLORS) {
    df_elem <- df %>%
        dplyr::mutate(Elemental_Class = dplyr::case_when(
            N == 0 & S == 0 ~ "CHO", N > 0 & S == 0 ~ "CHON",
            N == 0 & S > 0 ~ "CHOS", N > 0 & S > 0 ~ "CHONS"
        ))

    df_summary <- df_elem %>%
        dplyr::filter(Abundance > 0) %>%
        dplyr::group_by(Sample, Elemental_Class) %>%
        dplyr::summarise(Total_Abund = sum(Abundance), .groups = "drop") %>%
        dplyr::group_by(Sample) %>%
        dplyr::mutate(Percent = Total_Abund / sum(Total_Abund) * 100) %>%
        dplyr::ungroup()

    ggplot2::ggplot(df_summary, ggplot2::aes(x = Sample, y = Percent, fill = Elemental_Class)) +
        ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::scale_fill_manual(values = elem_colors) +
        ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0, 101)) +
        ggplot2::labs(x = NULL, y = "Relative Abundance (%)", fill = "Class") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
}

#' VK 类别堆叠图
plot_category_stack <- function(df, vk_colors = VK_COLORS) {
    df_summary <- df %>%
        dplyr::filter(Abundance > 0) %>%
        dplyr::group_by(Sample, Category) %>%
        dplyr::summarise(Total = sum(Abundance, na.rm = TRUE), .groups = "drop") %>%
        dplyr::group_by(Sample) %>%
        dplyr::mutate(Percent = Total / sum(Total) * 100) %>%
        dplyr::ungroup()

    ggplot2::ggplot(df_summary, ggplot2::aes(x = Sample, y = Percent, fill = Category)) +
        ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::scale_fill_manual(values = vk_colors) +
        ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0, 101)) +
        ggplot2::labs(x = NULL, y = "Relative Abundance (%)", fill = "Category") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
}

#' Alpha 多样性柱状图
plot_alpha_diversity <- function(alpha_df, metric = "Shannon") {
    ggplot2::ggplot(alpha_df, ggplot2::aes(x = Sample, y = .data[[metric]], fill = Sample)) +
        ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::geom_text(ggplot2::aes(label = round(.data[[metric]], 2)), vjust = -0.3, size = 3) +
        ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.15))) +
        ggplot2::labs(x = NULL, y = metric, title = paste(metric, "Diversity")) +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1), legend.position = "none")
}

#' PCoA 散点图 (支持分组、圈选和动态标题)
plot_pcoa <- function(pcoa_result, metadata = NULL, show_ellipse = FALSE, ellipse_level = 0.95) {
    points_df <- pcoa_result$points
    eig_pct <- pcoa_result$eig_pct
    method_name <- tools::toTitleCase(pcoa_result$method) # 获取方法名用于标题

    # 1. 处理元数据
    if (!is.null(metadata)) {
        if (!"Sample" %in% colnames(metadata)) colnames(metadata)[1] <- "Sample"
        if (ncol(metadata) >= 2 && !"Group" %in% colnames(metadata)) colnames(metadata)[2] <- "Group"

        points_df <- points_df %>%
            dplyr::left_join(metadata, by = "Sample") %>%
            dplyr::mutate(Group = as.factor(tidyr::replace_na(as.character(Group), "Ungrouped")))
    } else {
        points_df$Group <- "All"
    }

    # 2. 基础绘图
    p <- ggplot2::ggplot(points_df, ggplot2::aes(x = PCoA1, y = PCoA2)) +
        ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "grey70") +
        ggplot2::geom_vline(xintercept = 0, linetype = "dashed", color = "grey70")

    # 3. 分组绘图逻辑
    if (!is.null(metadata)) {
        p <- p +
            ggplot2::geom_point(ggplot2::aes(fill = Group), shape = 21, size = 4, color = "black") +
            ggplot2::labs(fill = "Group")

        if (show_ellipse) {
            group_counts <- table(points_df$Group)

            # n >= 3: 置信椭圆
            groups_ellipse <- names(group_counts[group_counts >= 3])
            if (length(groups_ellipse) > 0) {
                data_ellipse <- points_df %>% dplyr::filter(Group %in% groups_ellipse)
                p <- p + ggplot2::stat_ellipse(
                    data = data_ellipse,
                    ggplot2::aes(color = Group, fill = Group),
                    geom = "polygon", alpha = 0.1, level = ellipse_level, show.legend = FALSE
                )
            }

            # 1 < n < 3: 凸包
            groups_hull <- names(group_counts[group_counts > 1 & group_counts < 3])
            if (length(groups_hull) > 0) {
                data_hull <- points_df %>%
                    dplyr::filter(Group %in% groups_hull) %>%
                    dplyr::group_by(Group) %>%
                    dplyr::slice(chull(PCoA1, PCoA2))

                p <- p + ggplot2::geom_polygon(
                    data = data_hull,
                    ggplot2::aes(color = Group, fill = Group),
                    alpha = 0.1, linetype = "dashed", show.legend = FALSE
                )
            }
        }
    } else {
        p <- p + ggplot2::geom_point(ggplot2::aes(fill = Sample), shape = 21, size = 4, color = "black") +
            ggplot2::theme(legend.position = "none")
    }

    # 4. 标签和主题
    p <- p +
        ggrepel::geom_text_repel(ggplot2::aes(label = Sample), size = 3, max.overlaps = 20) +
        ggplot2::labs(
            title = paste0("PCoA (", method_name, ")"), # 动态标题
            x = paste0("PCoA1 (", eig_pct[1], "%)"),
            y = paste0("PCoA2 (", eig_pct[2], "%)")
        ) +
        cowplot::theme_half_open(font_size = 12)

    return(p)
}


#' DBE vs Carbon Number 图
plot_dbe_c <- function(df, sample_id, vk_colors = VK_COLORS) {
    plot_data <- df %>% dplyr::filter(Sample == sample_id, Abundance > 0)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = C, y = DBE, color = Category)) +
        ggplot2::geom_point(size = 0.8, alpha = 0.5) +
        ggplot2::geom_abline(slope = 0.5, intercept = 0.5, linetype = "dashed", color = "grey40", linewidth = 0.4) +
        ggplot2::geom_abline(slope = 0.67, intercept = 0.67, linetype = "dashed", color = "grey40", linewidth = 0.4) +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_x_continuous(limits = c(0, 50), breaks = seq(0, 50, 10)) +
        ggplot2::scale_y_continuous(limits = c(0, 25), breaks = seq(0, 25, 5)) +
        ggplot2::labs(x = "Carbon Number", y = "DBE", title = sample_id, subtitle = "Dashed: AI = 0.5, 0.67") +
        cowplot::theme_half_open(font_size = 11) +
        ggplot2::theme(legend.position = "right", panel.grid.major = ggplot2::element_line(color = "grey92", linewidth = 0.3))
}

#' DBE vs C 分面图
plot_dbe_c_facet <- function(df, vk_colors = VK_COLORS, ncol = 3) {
    plot_data <- df %>% dplyr::filter(Abundance > 0)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = C, y = DBE, color = Category)) +
        ggplot2::geom_point(size = 0.5, alpha = 0.4) +
        ggplot2::geom_abline(slope = 0.5, intercept = 0.5, linetype = "dashed", color = "grey40", linewidth = 0.3) +
        ggplot2::geom_abline(slope = 0.67, intercept = 0.67, linetype = "dashed", color = "grey40", linewidth = 0.3) +
        ggplot2::facet_wrap(~Sample, ncol = ncol) +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_x_continuous(limits = c(0, 50), breaks = seq(0, 50, 20)) +
        ggplot2::scale_y_continuous(limits = c(0, 25), breaks = seq(0, 25, 10)) +
        ggplot2::labs(x = "Carbon Number", y = "DBE", title = "DBE vs Carbon Number") +
        cowplot::theme_half_open(font_size = 10) +
        ggplot2::theme(legend.position = "right", strip.background = ggplot2::element_rect(fill = "grey95"))
}

#' KMD 图
plot_kmd <- function(df, sample_id, vk_colors = VK_COLORS) {
    plot_data <- df %>%
        dplyr::filter(Sample == sample_id, Abundance > 0) %>%
        dplyr::mutate(KM = MW * (14.00000 / 14.01565), NKM = round(KM), KMD = (NKM - KM) * 1000)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = KM, y = KMD, color = Category)) +
        ggplot2::geom_point(size = 0.8, alpha = 0.5) +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_x_continuous(breaks = seq(200, 800, 200)) +
        ggplot2::labs(x = "Kendrick Mass", y = "KMD (×1000)", title = sample_id) +
        cowplot::theme_half_open(font_size = 11) +
        ggplot2::theme(legend.position = "right", panel.grid.major = ggplot2::element_line(color = "grey92", linewidth = 0.3))
}

#' KMD 分面图
plot_kmd_facet <- function(df, vk_colors = VK_COLORS, ncol = 3) {
    plot_data <- df %>%
        dplyr::filter(Abundance > 0) %>%
        dplyr::mutate(KM = MW * (14.00000 / 14.01565), NKM = round(KM), KMD = (NKM - KM) * 1000)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = KM, y = KMD, color = Category)) +
        ggplot2::geom_point(size = 0.5, alpha = 0.4) +
        ggplot2::facet_wrap(~Sample, ncol = ncol) +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_x_continuous(breaks = seq(200, 800, 200)) +
        ggplot2::labs(x = "Kendrick Mass", y = "KMD (×1000)", title = "KMD Plot") +
        cowplot::theme_half_open(font_size = 10) +
        ggplot2::theme(legend.position = "right", strip.background = ggplot2::element_rect(fill = "grey95"))
}

#' 分子量分布密度图
plot_mw_distribution <- function(df, sample_id, vk_colors = VK_COLORS) {
    plot_data <- df %>% dplyr::filter(Sample == sample_id, Abundance > 0)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = MW, fill = Category, weight = Abundance)) +
        ggplot2::geom_density(alpha = 0.6, color = NA) +
        ggplot2::scale_fill_manual(values = vk_colors) +
        ggplot2::scale_x_continuous(limits = c(100, 800), breaks = seq(200, 800, 200)) +
        ggplot2::labs(x = "Molecular Weight (Da)", y = "Density", title = sample_id) +
        cowplot::theme_half_open(font_size = 11) +
        ggplot2::theme(legend.position = "right")
}

#' NOSC vs MW 图
plot_nosc_mw <- function(df, sample_id, vk_colors = VK_COLORS) {
    plot_data <- df %>% dplyr::filter(Sample == sample_id, Abundance > 0, NOSC >= -2.5 & NOSC <= 2.5)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = MW, y = NOSC, color = Category)) +
        ggplot2::geom_point(size = 0.8, alpha = 0.5) +
        ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_y_continuous(limits = c(-2.5, 2.5)) +
        ggplot2::labs(x = "Molecular Weight (Da)", y = "NOSC", title = sample_id) +
        cowplot::theme_half_open(font_size = 11) +
        ggplot2::theme(legend.position = "right", panel.grid.major.y = ggplot2::element_line(color = "grey92", linewidth = 0.3))
}

#' N/C vs O/C 图
plot_nc_oc <- function(df, sample_id, vk_colors = VK_COLORS) {
    plot_data <- df %>% dplyr::filter(Sample == sample_id, Abundance > 0, N > 0)
    if (nrow(plot_data) == 0) {
        return(NULL)
    }

    ggplot2::ggplot(plot_data, ggplot2::aes(x = OC, y = NC, color = Category)) +
        ggplot2::geom_point(size = 1, alpha = 0.6) +
        ggplot2::scale_color_manual(values = vk_colors) +
        ggplot2::scale_x_continuous(limits = c(0, 1.2)) +
        ggplot2::scale_y_continuous(limits = c(0, 0.5)) +
        ggplot2::labs(x = "O/C", y = "N/C", title = paste(sample_id, "- N-containing")) +
        cowplot::theme_half_open(font_size = 11) +
        ggplot2::theme(legend.position = "right")
}

#' Gibbs 自由能分布图
plot_gibbs_distribution <- function(df) {
    plot_data <- df %>% dplyr::filter(Abundance > 0, NOSC >= -2.5 & NOSC <= 2.5, C >= 5)

    ggplot2::ggplot(plot_data, ggplot2::aes(x = Sample, y = Gibbs, fill = Sample)) +
        ggplot2::geom_violin(alpha = 0.7, trim = TRUE, scale = "width", color = NA) +
        ggplot2::geom_boxplot(width = 0.15, color = "black", alpha = 0.9, outlier.shape = NA) +
        ggplot2::coord_cartesian(ylim = c(0, 130)) +
        ggplot2::labs(title = "Gibbs Free Energy Distribution", y = expression(Delta * G[Cox] ~ (kJ ~ mol ~ C^{
            -1
        })), x = NULL) +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(
            axis.text.x = ggplot2::element_text(angle = 45, hjust = 1), legend.position = "none",
            panel.grid.major.y = ggplot2::element_line(color = "grey90", linewidth = 0.3)
        )
}

#' 活性指数堆叠图
plot_lability_stack <- function(lability_result, lability_colors = LABILITY_COLORS) {
    # 检查必要字段是否存在
    if (is.null(lability_result$detail) || nrow(lability_result$detail) == 0) {
        return(NULL)
    }

    plot_data <- lability_result$detail %>%
        dplyr::mutate(Lability_Type = factor(Lability_Type, levels = c("Recalcitrant", "Intermediate", "Labile")))

    ggplot2::ggplot(plot_data, ggplot2::aes(x = Sample, y = Percent, fill = Lability_Type)) +
        ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::scale_fill_manual(values = lability_colors) +
        ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0, 101)) +
        ggplot2::labs(x = NULL, y = "Relative Abundance (%)", fill = "Lability", title = "Molecular Lability") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
}

#' 活性指数柱状图
plot_lability_index <- function(lability_result) {
    # 检查必要字段是否存在
    if (is.null(lability_result$index) || nrow(lability_result$index) == 0) {
        return(NULL)
    }

    plot_data <- lability_result$index

    ggplot2::ggplot(plot_data, ggplot2::aes(x = Sample, y = Lability_Index, fill = Sample)) +
        ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::geom_hline(yintercept = 0.5, linetype = "dashed", color = "grey40") +
        ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0, 1)) +
        ggplot2::labs(x = NULL, y = "Lability Index", title = "Lability Index") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1), legend.position = "none")
}

#' CRAM 比例堆叠图
plot_cram_stack <- function(cram_data, cram_colors = CRAM_COLORS) {
    plot_data <- cram_data %>% dplyr::mutate(is_CRAM = factor(is_CRAM, levels = c("Non-CRAM", "CRAM")))

    ggplot2::ggplot(plot_data, ggplot2::aes(x = Sample, y = Abund_Pct, fill = is_CRAM)) +
        ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::scale_fill_manual(values = cram_colors) +
        ggplot2::scale_y_continuous(expand = c(0, 0), limits = c(0, 101)) +
        ggplot2::labs(x = NULL, y = "Relative Abundance (%)", fill = "Type", title = "CRAM Proportion") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
}

#' CRAM VK 图
plot_cram_vk <- function(df, sample_id, vk_zones = VK_ZONES) {
    plot_data <- df %>%
        dplyr::filter(Sample == sample_id, Abundance > 0) %>%
        assign_cram_category()

    ggplot2::ggplot(plot_data, ggplot2::aes(x = OC, y = HC, color = is_CRAM)) +
        ggplot2::geom_point(size = 1, alpha = 0.5) +
        ggplot2::geom_rect(
            data = data.frame(xmin = 0.20, xmax = 0.90, ymin = 0.70, ymax = 1.50),
            ggplot2::aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            inherit.aes = FALSE, fill = NA, color = "#1f77b4", linetype = "solid", linewidth = 0.8
        ) +
        ggplot2::annotate("text", x = 0.55, y = 1.55, label = "CRAM region", color = "#1f77b4", size = 3.5) +
        ggplot2::scale_color_manual(values = CRAM_COLORS) +
        ggplot2::scale_x_continuous(limits = c(0, 1.2), expand = c(0.02, 0)) +
        ggplot2::scale_y_continuous(limits = c(0, 2.5), expand = c(0.02, 0)) +
        ggplot2::labs(x = "O/C", y = "H/C", title = paste(sample_id, "- CRAM"), color = "Type") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(legend.position = "right")
}

#' 差异分析 VK 图
plot_diff_vk <- function(diff_result, vk_zones = VK_ZONES) {
    plot_data <- diff_result %>% dplyr::filter(Diff_Status %in% c("Group A only", "Group B only"))
    if (nrow(plot_data) == 0) {
        return(NULL)
    }

    diff_colors <- c("Group A only" = "#d73027", "Group B only" = "#4575b4")

    ggplot2::ggplot(plot_data, ggplot2::aes(x = OC, y = HC, color = Diff_Status)) +
        ggplot2::geom_point(size = 1, alpha = 0.6) +
        ggplot2::geom_rect(
            data = vk_zones, ggplot2::aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            inherit.aes = FALSE, fill = NA, color = "gray40", linetype = "dashed", linewidth = 0.3
        ) +
        ggplot2::geom_text(
            data = vk_zones %>% dplyr::mutate(label_x = ifelse(xmin == 0, 0.03, (xmin + xmax) / 2), label_y = (ymin + ymax) / 2),
            ggplot2::aes(x = label_x, y = label_y, label = Category), inherit.aes = FALSE, size = 2.5, fontface = "italic", hjust = 0, color = "gray40"
        ) +
        ggplot2::scale_color_manual(values = diff_colors) +
        ggplot2::scale_x_continuous(limits = c(0, 1.2), expand = c(0.02, 0)) +
        ggplot2::scale_y_continuous(limits = c(0, 2.5), expand = c(0.02, 0)) +
        ggplot2::labs(x = "O/C", y = "H/C", title = "Unique Molecules", color = "Status") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(legend.position = "right")
}

#' 差异分析类别柱状图
plot_diff_category <- function(diff_result, vk_colors = VK_COLORS) {
    plot_data <- diff_result %>%
        dplyr::filter(Diff_Status %in% c("Group A only", "Group B only")) %>%
        dplyr::count(Diff_Status, Category)
    if (nrow(plot_data) == 0) {
        return(NULL)
    }

    diff_colors <- c("Group A only" = "#d73027", "Group B only" = "#4575b4")

    ggplot2::ggplot(plot_data, ggplot2::aes(x = Category, y = n, fill = Diff_Status)) +
        ggplot2::geom_col(position = "dodge", width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::scale_fill_manual(values = diff_colors) +
        ggplot2::labs(x = NULL, y = "Count", title = "Unique by Category", fill = "Status") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))
}

#' UpSet 图
plot_upset <- function(df, sample_cols, vk_colors = VK_COLORS, n_intersections = 30, min_size = 5) {
    upset_data <- df %>%
        dplyr::select(Formula, Category, Sample, Abundance) %>%
        tidyr::pivot_wider(names_from = Sample, values_from = Abundance, values_fill = 0) %>%
        dplyr::mutate(across(all_of(sample_cols), ~ ifelse(. > 0, 1, 0)))
    upset_data$Category <- factor(upset_data$Category, levels = names(vk_colors))

    ComplexUpset::upset(upset_data,
        intersect = sample_cols, name = "Intersection",
        n_intersections = n_intersections, min_size = min_size, width_ratio = 0.15, sort_sets = FALSE,
        base_annotations = list("Size" = ComplexUpset::intersection_size(counts = FALSE, mapping = ggplot2::aes(fill = Category)) +
            ggplot2::scale_fill_manual(values = vk_colors) + ggplot2::theme(legend.position = "none")),
        set_sizes = ComplexUpset::upset_set_size(geom = ggplot2::geom_bar(ggplot2::aes(fill = Category, x = group), width = 0.6)) +
            ggplot2::scale_fill_manual(values = vk_colors) +
            ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 90), legend.position = "right"),
        themes = ComplexUpset::upset_default_themes(text = ggplot2::element_text(size = 10))
    )
}

#' 相关性热图
plot_correlation_heatmap <- function(cor_result, show_coef = TRUE) {
    cor_mat <- cor_result$cor
    p_mat <- cor_result$p

    cor_df <- as.data.frame(cor_mat) %>%
        tibble::rownames_to_column("Var1") %>%
        tidyr::pivot_longer(-Var1, names_to = "Var2", values_to = "Correlation")

    p_df <- as.data.frame(p_mat) %>%
        tibble::rownames_to_column("Var1") %>%
        tidyr::pivot_longer(-Var1, names_to = "Var2", values_to = "p_value")

    plot_data <- cor_df %>%
        dplyr::left_join(p_df, by = c("Var1", "Var2")) %>%
        dplyr::mutate(
            sig = dplyr::case_when(p_value < 0.001 ~ "***", p_value < 0.01 ~ "**", p_value < 0.05 ~ "*", TRUE ~ ""),
            label = ifelse(show_coef, paste0(round(Correlation, 2), sig), sig)
        )

    var_order <- colnames(cor_mat)
    plot_data$Var1 <- factor(plot_data$Var1, levels = var_order)
    plot_data$Var2 <- factor(plot_data$Var2, levels = rev(var_order))

    ggplot2::ggplot(plot_data, ggplot2::aes(x = Var1, y = Var2, fill = Correlation)) +
        ggplot2::geom_tile(color = "white") +
        ggplot2::geom_text(ggplot2::aes(label = label), size = 2.5) +
        ggplot2::scale_fill_gradient2(low = "#2166ac", mid = "white", high = "#b2182b", midpoint = 0, limits = c(-1, 1)) +
        ggplot2::labs(x = NULL, y = NULL, title = "Correlation", subtitle = "* p<0.05, ** p<0.01, *** p<0.001") +
        ggplot2::theme_minimal(base_size = 11) +
        ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1), panel.grid = ggplot2::element_blank())
}

#' 绘制火山图
plot_volcano <- function(stat_result, group_a_name = "Group A", group_b_name = "Group B") {
    # 设置颜色
    volcano_colors <- c(
        "Enriched in A" = "#d73027", # 红
        "Enriched in B" = "#4575b4", # 蓝
        "Not Sig" = "grey80"
    )

    # 标签
    label_map <- c(
        "Enriched in A" = paste("Enriched in", group_a_name),
        "Enriched in B" = paste("Enriched in", group_b_name),
        "Not Sig" = "Not Significant"
    )

    p <- ggplot2::ggplot(stat_result, ggplot2::aes(x = Log2FC, y = -log10(P_Value), color = Significance)) +
        ggplot2::geom_point(alpha = 0.6, size = 1.5) +
        ggplot2::geom_vline(xintercept = c(-1, 1), linetype = "dashed", color = "grey50") +
        ggplot2::geom_hline(yintercept = -log10(0.05), linetype = "dashed", color = "grey50") +
        ggplot2::scale_color_manual(values = volcano_colors, labels = label_map) +
        ggplot2::labs(
            x = expression(log[2] ~ "Fold Change"),
            y = expression(-log[10] ~ "P-value"),
            title = "Volcano Plot",
            color = "Status"
        ) +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(legend.position = "top")

    return(p)
}

#' 绘制差异分子 VK 图
plot_stat_vk <- function(stat_result, vk_zones = VK_ZONES) {
    # 只画显著的
    plot_data <- stat_result %>% dplyr::filter(Significance != "Not Sig")

    if (nrow(plot_data) == 0) {
        return(NULL)
    }

    volcano_colors <- c(
        "Enriched in A" = "#d73027",
        "Enriched in B" = "#4575b4"
    )

    ggplot2::ggplot(plot_data, ggplot2::aes(x = OC, y = HC, color = Significance)) +
        ggplot2::geom_point(size = 1, alpha = 0.6) +
        ggplot2::geom_rect(
            data = vk_zones, ggplot2::aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
            inherit.aes = FALSE, fill = NA, color = "gray40", linetype = "dashed", linewidth = 0.3
        ) +
        ggplot2::scale_color_manual(values = volcano_colors) +
        ggplot2::scale_x_continuous(limits = c(0, 1.2)) +
        ggplot2::scale_y_continuous(limits = c(0, 2.5)) +
        ggplot2::labs(x = "O/C", y = "H/C", title = "Significant Molecules VK", color = "Status") +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(legend.position = "right")
}

#' 绘制转化频率图
plot_transformation_bar <- function(trans_res) {
    if (is.null(trans_res) || nrow(trans_res) == 0) {
        return(NULL)
    }

    plot_data <- trans_res %>%
        dplyr::count(Transformation) %>%
        dplyr::mutate(Transformation = reorder(Transformation, n))

    ggplot2::ggplot(plot_data, ggplot2::aes(x = Transformation, y = n, fill = Transformation)) +
        ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
        ggplot2::coord_flip() +
        ggplot2::scale_fill_brewer(palette = "Set2") +
        ggplot2::labs(
            x = NULL,
            y = "Count of Putative Transformations",
            title = "Transformation Frequency",
            subtitle = "Based on mass difference analysis"
        ) +
        cowplot::theme_half_open(font_size = 12) +
        ggplot2::theme(legend.position = "none")
}


#' 绘制转化网络图
#' @param graph tbl_graph 对象
#' @param color_by 节点着色依据 ("Category", "OC", "HC", "community")
#' @param layout 布局算法 ("fr", "kk", "nicely")
plot_transformation_network <- function(graph, color_by = "Category", layout = "fr") {
    # 依赖包: ggraph

    if (is.null(graph)) {
        return(NULL)
    }

    # 基础绘图
    p <- ggraph::ggraph(graph, layout = layout) +
        # 绘制边 (根据转化类型着色，透明度低一点)
        ggraph::geom_edge_link(ggplot2::aes(color = type), alpha = 0.4, width = 0.5) +
        ggraph::scale_edge_color_brewer(palette = "Set2", name = "Transformation")

    # 绘制节点
    if (color_by == "Category") {
        p <- p + ggraph::geom_node_point(ggplot2::aes(color = Category, size = degree), alpha = 0.9) +
            ggplot2::scale_color_manual(values = VK_COLORS)
    } else if (color_by == "community") {
        p <- p + ggraph::geom_node_point(ggplot2::aes(color = community, size = degree), alpha = 0.9) +
            ggplot2::labs(color = "Module")
    } else {
        # 连续变量 (OC, HC)
        p <- p + ggraph::geom_node_point(ggplot2::aes(color = .data[[color_by]], size = degree), alpha = 0.9) +
            ggplot2::scale_color_viridis_c(option = "magma", name = color_by)
    }

    # 调整样式
    p <- p +
        ggplot2::scale_size_continuous(range = c(1, 6), name = "Degree") +
        ggraph::theme_graph(base_family = "sans") +
        ggplot2::labs(title = "Molecular Transformation Network")

    return(p)
}
