# ==============================================================================
# mod_diversity.R - Alpha 多样性模块 (完整版)
# ==============================================================================

mod_diversity_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "Alpha 多样性",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                selectInput(ns("metric"), "多样性指标：",
                    choices = c("Richness", "Shannon", "Simpson", "Pielou"),
                    selected = "Shannon"
                ),
                ui_display_settings(ns, default_w = 800, default_h = 600),
                ui_export_settings(ns, default_w = 8, default_h = 5),
                hr(),
                downloadButton(ns("download_csv"), "下载数据表")
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),

                # 使用标准化的分析信息面板
                uiOutput(ns("info_panel")),
                hr(),
                h5("多样性数据表"),
                tableOutput(ns("table"))
            )
        )
    )
}

mod_diversity_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 标准化的响应式逻辑
        plot_reactive <- reactive({
            req(rv$alpha_div)
            if (!validate_sufficient_data(rv$alpha_div, 1, "多样性分析")) {
                return(NULL)
            }
            plot_alpha_diversity(rv$alpha_div, input$metric)
        })
        
        # 使用标准化的容器和绘图函数
        render_plot_container(output, session$ns, input)
        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        # 标准化的分析信息面板
        output$info_panel <- renderUI({
            req(rv$alpha_div)
            
            info_items <- list(
                list(label = "Richness (丰富度):", description = "样品中检测到的分子式总数量，反映DOM的化学复杂性"),
                list(label = "Shannon Index:", description = "综合考虑丰富度和均匀度，值越高分子种类越多且分布越均匀"),
                list(label = "Simpson Index:", description = "对优势物种（高丰度分子）更敏感"),
                list(label = "Pielou Evenness:", description = "反映分子丰度分布的均匀程度（0~1）")
            )
            
            ui_analysis_info_panel(session$ns, "指标含义", info_items, icon = "info-circle")
        })

        output$table <- renderTable({
            req(rv$alpha_div)
            rv$alpha_div %>% dplyr::mutate(across(where(is.numeric), ~ round(.x, 3)))
        })

        # 使用标准化的文件命名
        filename_base <- reactive({
            generate_filename("Alpha", input$metric)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)

        output$download_csv <- downloadHandler(
            filename = function() "Alpha_Diversity.csv",
            content = function(file) readr::write_csv(rv$alpha_div, file)
        )
    })
}
