# ==============================================================================
# mod_diff.R - 差异分析模块 (完整版)
# ==============================================================================

mod_diff_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "差异分析",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                h5("分组设置"),
                uiOutput(ns("group_a_selector")),
                uiOutput(ns("group_b_selector")),
                actionButton(ns("btn_run"), "执行分析", class = "btn-success", icon = icon("calculator")),
                hr(),
                radioButtons(ns("plot_type"), "图类型：",
                    choices = c("VK 图" = "vk", "类别柱状图" = "bar"),
                    selected = "vk"
                ),
                ui_display_settings(ns, default_w = 900, default_h = 600), # 新增
                ui_export_settings(ns, default_w = 8, default_h = 6),
                hr(),
                downloadButton(ns("download_csv"), "下载差异表")
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),

                # ---- 新增：解释文本 ----
                div(
                    class = "alert alert-info", style = "margin-top: 20px;",
                    h5(icon("info-circle"), "分析逻辑："),
                    p("该模块基于分子的", strong("存在/缺失 (Presence/Absence)"), "进行定性比较。"),
                    tags$ul(
                        tags$li(strong("Group A only:"), " 仅在 A 组样品中检测到的分子（特异性分子）。"),
                        tags$li(strong("Group B only:"), " 仅在 B 组样品中检测到的分子。"),
                        tags$li(strong("Shared:"), " 两组均检测到的分子。"),
                        tags$li("注意：此分析不考虑丰度高低，仅考虑是否检出。若需比较丰度显著差异，请使用“统计差异”模块。")
                    )
                ),
                hr(),
                h5("差异统计"),
                tableOutput(ns("summary"))
            )
        )
    )
}

mod_diff_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        ns <- session$ns

        output$group_a_selector <- renderUI({
            req(rv$processed_data)
            selectInput(ns("group_a"), "Group A：", choices = unique(rv$processed_data$Sample), multiple = TRUE)
        })

        output$group_b_selector <- renderUI({
            req(rv$processed_data)
            selectInput(ns("group_b"), "Group B：", choices = unique(rv$processed_data$Sample), multiple = TRUE)
        })

        observeEvent(input$btn_run, {
            req(rv$processed_data, input$group_a, input$group_b)
            if (length(input$group_a) == 0 || length(input$group_b) == 0) {
                showNotification("请为两组各选至少一个样品", type = "warning")
                return()
            }
            withProgress(message = "差异分析...", {
                rv$diff_result <- perform_diff_analysis(rv$processed_data, input$group_a, input$group_b)
            })
        })

        plot_reactive <- reactive({
            req(rv$diff_result)
            if (input$plot_type == "vk") {
                plot_diff_vk(rv$diff_result)
            } else {
                plot_diff_category(rv$diff_result)
            }
        })
        render_plot_container(output, session$ns, input)

        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        output$summary <- renderTable({
            req(rv$diff_result)
            rv$diff_result %>%
                dplyr::count(Diff_Status) %>%
                dplyr::rename(状态 = Diff_Status, 数量 = n)
        })

        filename_base <- reactive({
            paste0("Diff_", input$plot_type)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)

        output$download_csv <- downloadHandler(
            filename = function() "Diff_Analysis.csv",
            content = function(file) readr::write_csv(rv$diff_result, file)
        )
    })
}
