# ==============================================================================
# mod_data_upload.R - 数据上传与预处理模块 (增强版)
# ==============================================================================

mod_data_upload_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "数据上传",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                fileInput(ns("file_upload"), "上传 CSV 文件（可多选）", multiple = TRUE, accept = ".csv"),
                hr(),
                h5("预处理选项"),
                checkboxInput(ns("do_tic"), "TIC 标准化", value = TRUE),
                uiOutput(ns("bg_selector")),
                hr(),
                uiOutput(ns("sample_selector")),
                hr(),
                actionButton(ns("btn_process"), "处理数据", class = "btn-primary", icon = icon("play"))
            ),
            mainPanel(
                width = 9,
                h4("上传文件列表"),
                tableOutput(ns("file_list")),
                hr(),
                h4("样品基本统计"),
                tableOutput(ns("sample_stats")), # 改名
                textOutput(ns("data_summary"))
            )
        )
    )
}

mod_data_upload_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        ns <- session$ns

        # ... (之前的上传和处理逻辑保持不变) ...

        # 上传文件后更新样品列表
        observeEvent(input$file_upload, {
            req(input$file_upload)
            rv$sample_names <- tools::file_path_sans_ext(input$file_upload$name)
            rv$file_info <- input$file_upload
        })

        output$file_list <- renderTable({
            req(input$file_upload)
            data.frame(
                文件名 = input$file_upload$name,
                大小 = paste(round(input$file_upload$size / 1024, 1), "KB")
            )
        })

        output$bg_selector <- renderUI({
            req(rv$sample_names)
            selectInput(ns("bg_sample"), "背景样品（可选）：",
                choices = c("无" = "", rv$sample_names), selected = ""
            )
        })

        output$sample_selector <- renderUI({
            req(rv$sample_names)
            checkboxGroupInput(ns("selected_samples"), "选择要分析的样品：",
                choices = rv$sample_names, selected = rv$sample_names
            )
        })

        # 处理数据逻辑 (保持不变)
        observeEvent(input$btn_process, {
            req(rv$file_info, input$selected_samples)

            file_df <- rv$file_info
            selected_idx <- tools::file_path_sans_ext(file_df$name) %in% input$selected_samples
            file_df <- file_df[selected_idx, ]

            withProgress(message = "正在处理数据...", value = 0, {
                incProgress(0.15, detail = "读取文件...")
                df <- process_uploaded_data(file_df)

                if (input$do_tic) {
                    incProgress(0.15, detail = "TIC 标准化...")
                    df <- normalize_tic(df)
                }

                if (!is.null(input$bg_sample) && input$bg_sample != "") {
                    incProgress(0.1, detail = "扣除背景...")
                    df <- subtract_background(df, input$bg_sample)
                }

                rv$processed_data <- df

                incProgress(0.15, detail = "Alpha 多样性...")
                rv$alpha_div <- calculate_alpha_diversity(df)

                if (length(unique(df$Sample)) >= 3) {
                    incProgress(0.1, detail = "PCoA...")
                    rv$pcoa_result <- calculate_pcoa(df)
                }

                incProgress(0.1, detail = "加权性质...")
                rv$wa_data <- calculate_weighted_averages(df)

                incProgress(0.1, detail = "活性指数...")
                rv$lability_result <- calculate_lability(df)

                incProgress(0.1, detail = "CRAM...")
                rv$cram_data <- calculate_cram_abundance(df)

                incProgress(0.05, detail = "汇总...")
                rv$export_data <- export_summary_data(df, rv$alpha_div, rv$wa_data, rv$lability_result, rv$cram_data)
            })

            showNotification(paste("处理完成！共", length(unique(rv$processed_data$Sample)), "个样品"), type = "message")
        })

        # --- 修改部分：样品统计预览 ---
        output$sample_stats <- renderTable({
            req(rv$processed_data)

            rv$processed_data %>%
                dplyr::group_by(Sample) %>%
                dplyr::summarise(
                    Formula_Count = dplyr::n(),
                    Mean_MW = mean(MW, na.rm = TRUE),
                    Mean_OC = mean(OC, na.rm = TRUE),
                    Mean_HC = mean(HC, na.rm = TRUE),
                    Mean_DBE = mean(DBE, na.rm = TRUE),
                    .groups = "drop"
                ) %>%
                dplyr::mutate(across(where(is.numeric), ~ round(.x, 3))) %>%
                head(15) # 限制显示行数，防止太长
        })

        output$data_summary <- renderText({
            req(rv$processed_data)
            paste0("共 ", length(unique(rv$processed_data$Sample)), " 个样品，", nrow(rv$processed_data), " 条分子式记录")
        })
    })
}
