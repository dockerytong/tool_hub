# ==============================================================================
# mod_composition.R - 组成分析模块 (完整版)
# ==============================================================================

mod_composition_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "组成分析",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                radioButtons(ns("stack_type"), "堆叠图类型：",
                    choices = c("元素组成" = "elemental", "VK 类别" = "category"),
                    selected = "elemental"
                ),
                ui_display_settings(ns, default_w = 1000, default_h = 600),
                ui_export_settings(ns, default_w = 10, default_h = 6)
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),
                uiOutput(ns("info_panel"))
            )
        )
    )
}

mod_composition_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 标准化的响应式逻辑
        plot_reactive <- reactive({
            req(rv$processed_data)
            if (!validate_sufficient_data(rv$processed_data, 1, "组成分析")) {
                return(NULL)
            }
            
            if (input$stack_type == "elemental") {
                plot_elemental_stack(rv$processed_data)
            } else {
                plot_category_stack(rv$processed_data)
            }
        })
        
        # 使用标准化的容器和绘图函数
        render_plot_container(output, session$ns, input)
        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        # 标准化的分析信息面板
        output$info_panel <- renderUI({
            req(rv$processed_data)
            
            elemental_items <- list(
                list(label = "元素组成 (Elemental Class):", 
                     description = "展示不同杂原子类别（如 CHO, CHON, CHOS）的相对丰度，反映DOM的来源特征")
            )
            
            vk_items <- list(
                list(label = "VK 类别 (Van Krevelen Category):", 
                     description = "基于O/C和H/C比值划分的化学类别"),
                list(label = "Lipid-like:", description = "高H/C, 低O/C (脂肪族)"),
                list(label = "Lignin-like:", description = "中等H/C, 中等O/C (木质素类)"),
                list(label = "Condensed Aromatics:", description = "低H/C (稠环芳烃，通常指黑碳或高度腐殖化物质)")
            )
            
            info_items <- if (input$stack_type == "elemental") elemental_items else c(elemental_items, vk_items)
            
            ui_analysis_info_panel(session$ns, "分析说明", info_items, icon = "info-circle")
        })

        # 使用标准化的文件命名
        filename_base <- reactive({
            generate_filename("Stack", input$stack_type)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)
    })
}
