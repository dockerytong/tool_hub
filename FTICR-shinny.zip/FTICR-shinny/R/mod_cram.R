# ==============================================================================
# mod_cram.R - CRAM 模块 (完整版)
# ==============================================================================

mod_cram_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "CRAM 分析",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                radioButtons(ns("plot_type"), "图类型：",
                    choices = c("比例堆叠" = "stack", "VK 图" = "vk"),
                    selected = "stack"
                ),
                conditionalPanel(
                    condition = sprintf("input['%s'] == 'vk'", ns("plot_type")),
                    uiOutput(ns("sample_selector"))
                ),
                ui_display_settings(ns, default_w = 900, default_h = 600), # 新增
                ui_export_settings(ns, default_w = 8, default_h = 6),
                hr(),
                downloadButton(ns("download_csv"), "下载数据表")
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),
                uiOutput(ns("explanation")),

                # ---- 新增：解释文本 ----
                div(
                    class = "alert alert-info", style = "margin-top: 20px;",
                    h5(icon("info-circle"), "什么是 CRAM?"),
                    p(strong("CRAM (Carboxyl-Rich Alicyclic Molecules)"), " 即“富羧基脂环族分子”。"),
                    tags$ul(
                        tags$li("定义区域：DBE/C (0.30-0.68), O/C (0.20-0.90), H/C (0.70-1.50)。"),
                        tags$li("生态意义：CRAM 结构极其复杂，类似于复杂的萜类衍生物。它们被认为是海洋和土壤中", strong("难降解碳库 (Refractory Carbon)"), " 的主要组成部分，可以在环境中存在数千年。"),
                        tags$li("CRAM 比例越高，说明 DOM 越趋于老化和稳定。")
                    )
                ),
                hr(),
                tableOutput(ns("table"))
            )
        )
    )
}

mod_cram_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        ns <- session$ns

        output$sample_selector <- renderUI({
            req(rv$processed_data)
            selectInput(ns("sample"), "选择样品：", choices = unique(rv$processed_data$Sample))
        })

        plot_reactive <- reactive({
            req(rv$cram_data)
            if (input$plot_type == "stack") {
                plot_cram_stack(rv$cram_data)
            } else {
                req(rv$processed_data, input$sample)
                plot_cram_vk(rv$processed_data, input$sample)
            }
        })
        render_plot_container(output, session$ns, input)

        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        output$table <- renderTable({
            req(rv$cram_data)
            rv$cram_data %>% dplyr::mutate(across(where(is.numeric), ~ round(.x, 2)))
        })

        filename_base <- reactive({
            paste0("CRAM_", input$plot_type)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)

        output$download_csv <- downloadHandler(
            filename = function() "CRAM_Data.csv",
            content = function(file) readr::write_csv(rv$cram_data, file)
        )
    })
}
