# ==============================================================================
# fct_network.R - 分子网络分析函数
# ==============================================================================

#' 定义标准反应库
#' @description 定义分子间可能发生的反应及其质量变化
#' @return 包含反应名称和质量变化的列表
get_reaction_dict <- function() {
  list(
    decarboxylation = -44.00955,    # -CO2
    methylation = 14.01565,         # +CH2
    demethylation = -14.01565,      # -CH2
    hydrogenation = 2.01565,        # +H2
    dehydrogenation = -2.01565,     # -H2
    hydration = 18.01056,           # +H2O
    dehydration = -18.01056,        # -H2O
    oxidation = 15.99491,           # +O
    reduction = -15.99491,          # -O
    carboxylation = 43.98983,       # +CO2
    acetylation = 42.01056,         # +C2H2O
    condensation = -18.01056,       # -H2O (缩合)
    hydroxylation = 15.99491,       # +O (羟基化)
    dehydroxylation = -15.99491,    # -O (脱羟基)
    nitration = 44.99765,           # +NO2
    denitration = -44.99765,        # -NO2
    sulfation = 79.95682,           # +SO3
    desulfation = -79.95682,        # -SO3
    phosphorylation = 79.96633,     # +PO3
    dephosphorylation = -79.96633   # -PO3
  )
}

#' 计算分子质量
#' @param formula 分子式向量
#' @return 质量向量
calculate_formula_mass <- function(formula) {
  # 使用正则表达式解析分子式
  parse_formula <- function(f) {
    # 查找所有元素及其数量
    matches <- gregexpr("([A-Z][a-z]?)(\\d*)", f)
    elements <- regmatches(f, matches)[[1]]

    if(length(elements) == 0) return(0)

    elemental_masses <- c(
      C = 12.00000, H = 1.00783, O = 15.99491,
      N = 14.00307, S = 31.97207, P = 30.97376
    )

    mass <- 0
    for(element_full in elements) {
      # 解析元素符号和数量
      element_match <- regmatches(element_full, regexec("^([A-Z][a-z]?)(\\d*)$", element_full))[[1]]
      element <- element_match[2]
      count_str <- element_match[3]
      count <- if(count_str == "") 1 else as.numeric(count_str)

      if(element %in% names(elemental_masses)) {
        mass <- mass + elemental_masses[element] * count
      }
    }
    mass
  }

  sapply(formula, parse_formula)
}

#' 构建反应网络
#' @description 基于分子式和定义的反应类型构建网络
#' @param df 包含分子数据的数据框
#' @param reaction_dict 反应字典
#' @param mass_tolerance 质量容差 (ppm)
#' @return 包含网络信息的数据框
calculate_reaction_network <- function(df, reaction_dict = NULL, mass_tolerance = 5) {
  if (is.null(reaction_dict)) {
    reaction_dict <- get_reaction_dict()
  }

  # 提取唯一分子式和强度
  unique_molecules <- df[order(df$Formula), ]

  formula_list <- unique_molecules$Formula
  formula_mass <- calculate_formula_mass(formula_list)
  intensity <- unique_molecules$Abundance

  N <- length(formula_list)

  # 创建转移矩阵
  L <- matrix(0, nrow = N, ncol = N)

  # 构建反应网络
  for (j in seq_len(N)) {
    for (reaction_name in names(reaction_dict)) {
      reaction_mass <- reaction_dict[[reaction_name]]
      target_mass <- formula_mass[j] + reaction_mass

      # 查找匹配的分子（考虑质量容差）
      mass_diff <- abs(formula_mass - target_mass)
      match_index <- which(mass_diff <= (target_mass * mass_tolerance * 1e-6))

      if (length(match_index) > 0) {
        L[match_index, j] <- 1
      }
    }

    # 标准化概率
    if (sum(L[, j]) > 0) {
      L[, j] <- L[, j] / sum(L[, j])
    } else {
      L[, j] <- 1 / N
    }
  }

  # 构建边列表（用于可视化）
  edges <- data.frame(
    from = integer(),
    to = integer(),
    reaction = character(),
    mass_diff = numeric(),
    stringsAsFactors = FALSE
  )

  # 预计算所有可能的质量变化
  all_mass_diffs <- matrix(0, nrow = N, ncol = N)
  for (j in seq_len(N)) {
    for (i in seq_len(N)) {
      all_mass_diffs[i, j] <- formula_mass[i] - formula_mass[j]
    }
  }

  # 找出所有边
  edge_list <- list()
  edge_count <- 0

  for (j in seq_len(N)) {
    for (i in seq_len(N)) {
      if (L[i, j] > 0 && i != j) {
        # 确定反应类型
        best_reaction <- names(reaction_dict)[1]
        best_score <- -Inf

        for (reaction_name in names(reaction_dict)) {
          reaction_mass <- reaction_dict[[reaction_name]]
          target_mass <- formula_mass[j] + reaction_mass
          mass_diff <- abs(formula_mass[i] - target_mass)
          score <- 1 / (mass_diff + 1)

          if (score > best_score) {
            best_score <- score
            best_reaction <- reaction_name
          }
        }

        edge_count <- edge_count + 1
        edge_list[[edge_count]] <- data.frame(
          from = j,
          to = i,
          reaction = best_reaction,
          mass_diff = all_mass_diffs[i, j]
        )
      }
    }
  }

  # 合并所有边
  if (edge_count > 0) {
    edges <- do.call(rbind, edge_list)
  }

  # 返回网络数据
  list(
    nodes = data.frame(
      id = seq_len(N),
      formula = formula_list,
      mass = formula_mass,
      intensity = intensity,
      stringsAsFactors = FALSE
    ),
    edges = edges,
    transition_matrix = L
  )
}

#' PageRank算法
#' @description 计算网络中节点的重要性
#' @param network_data 网络数据（来自calculate_reaction_network）
#' @param damping_factor 阻尼系数（默认0.9）
#' @param tolerance 收敛容差
#' @param max_iter 最大迭代次数
#' @return 包含PageRank值的向量
calculate_pagerank <- function(network_data, damping_factor = 0.9, tolerance = 0.01, max_iter = 1000) {
  L <- network_data$transition_matrix
  N <- nrow(L)

  # 初始化概率向量
  r <- rep(1/N, N)

  # 构建PageRank矩阵
  M <- damping_factor * L + (1 - damping_factor) / N

  # 迭代计算
  for (i in seq_len(max_iter)) {
    last_r <- r
    r <- M %*% r

    if (sqrt(sum((r - last_r)^2)) < tolerance) {
      break
    }
  }

  # 返回结果
  data.frame(
    formula = network_data$nodes$formula,
    pagerank = as.numeric(r),
    intensity = network_data$nodes$intensity,
    mass = network_data$nodes$mass,
    stringsAsFactors = FALSE
  )
}

#' 分析网络属性
#' @description 计算网络的基本统计属性
#' @param network_data 网络数据
#' @return 网络属性列表
analyze_network_properties <- function(network_data) {
  edges <- network_data$edges
  nodes <- network_data$nodes

  # 基本统计
  n_nodes <- nrow(nodes)
  n_edges <- nrow(edges)
  density <- ifelse(n_nodes > 1, n_edges / (n_nodes * (n_nodes - 1)), 0)

  # 节点度统计
  in_degree <- table(factor(edges$to, levels = seq_len(n_nodes)))
  out_degree <- table(factor(edges$from, levels = seq_len(n_nodes)))

  # 反应类型统计
  reaction_counts <- table(edges$reaction)

  # 连通性分析
  connected_nodes <- union(edges$from, edges$to)
  isolated_nodes <- setdiff(seq_len(n_nodes), connected_nodes)

  list(
    summary = data.frame(
      n_nodes = n_nodes,
      n_edges = n_edges,
      density = density,
      n_isolated = length(isolated_nodes),
      stringsAsFactors = FALSE
    ),
    node_stats = data.frame(
      id = seq_len(n_nodes),
      formula = nodes$formula,
      in_degree = as.numeric(in_degree),
      out_degree = as.numeric(out_degree),
      total_degree = as.numeric(in_degree) + as.numeric(out_degree),
      stringsAsFactors = FALSE
    ),
    reaction_stats = data.frame(
      reaction = names(reaction_counts),
      count = as.numeric(reaction_counts),
      stringsAsFactors = FALSE
    )
  )
}

#' 识别关键分子
#' @description 基于PageRank和强度识别关键分子
#' @param pagerank_result PageRank结果
#' @param top_n 返回前N个分子
#' @return 关键分子列表
identify_key_molecules <- function(pagerank_result, top_n = 10) {
  # 确保数据按PageRank降序排列
  pagerank_result <- pagerank_result[order(-pagerank_result$pagerank), ]

  # 取前top_n个
  top_molecules <- head(pagerank_result, top_n)

  # 添加排名
  top_molecules$rank <- seq_len(nrow(top_molecules))
  top_molecules$intensity_rank <- rank(-top_molecules$intensity)

  top_molecules
}

#' 计算网络模块性
#' @description 使用随机游走算法识别网络社区
#' @param network_data 网络数据
#' @return 模块划分结果
calculate_network_modules <- function(network_data) {
  if (!requireNamespace("igraph", quietly = TRUE)) {
    stop("需要安装igraph包")
  }

  # 创建igraph对象
  g <- igraph::graph_from_data_frame(
    network_data$edges,
    directed = TRUE,
    vertices = network_data$nodes
  )

  # 使用随机游走算法检测社区
  modules <- igraph::cluster_walktrap(g)

  # 返回模块信息
  data.frame(
    formula = network_data$nodes$formula,
    module = as.numeric(modules$membership),
    stringsAsFactors = FALSE
  )
}

#' 构建转化网络
#' @description 基于转化结果构建分子转化网络
#' @param transformations 转化结果数据框 (来自calculate_transformations)
#' @param df 原始分子数据框
#' @return igraph对象表示的网络
build_transformation_network <- function(transformations, df) {
  if (!requireNamespace("igraph", quietly = TRUE)) {
    stop("需要安装igraph包")
  }

  # 提取所有涉及的分子
  all_formulas <- unique(c(transformations$Source_Formula, transformations$Target_Formula))

  # 从原始数据中获取分子的化学信息
  node_data <- df %>%
    dplyr::filter(Formula %in% all_formulas) %>%
    dplyr::distinct(Formula, .keep_all = TRUE) %>%
    dplyr::select(Formula, Category, OC, HC, MW, Abundance)

  # 如果某些分子在原始数据中没有找到，创建基本数据
  missing_formulas <- setdiff(all_formulas, node_data$Formula)
  if (length(missing_formulas) > 0) {
    missing_data <- data.frame(
      Formula = missing_formulas,
      Category = "Unknown",
      OC = NA,
      HC = NA,
      MW = NA,
      Abundance = 0
    )
    node_data <- dplyr::bind_rows(node_data, missing_data)
  }

  # 确保所有转化中的分子都在节点数据中
  transformations <- transformations[
    transformations$Source_Formula %in% node_data$Formula &
    transformations$Target_Formula %in% node_data$Formula,
  ]

  # 确保没有自环
  transformations <- transformations[
    transformations$Source_Formula != transformations$Target_Formula,
  ]

  if (nrow(transformations) == 0) {
    # 创建一个空的igraph对象
    g <- igraph::make_empty_graph(n = 0)
    return(g)
  }

  # 创建边
  edges <- data.frame(
    from = transformations$Source_Formula,
    to = transformations$Target_Formula,
    type = transformations$Transformation,
    stringsAsFactors = FALSE
  )

  # 创建igraph对象
  g <- igraph::graph_from_data_frame(
    edges,
    directed = TRUE,
    vertices = node_data
  )

  # 添加节点属性
  V(g)$degree <- igraph::degree(g)

  # 添加模块性信息（如果igraph可用）
  if (requireNamespace("igraph", quietly = TRUE)) {
    wc <- igraph::cluster_walktrap(g)
    V(g)$community <- as.numeric(wc$membership)
  } else {
    V(g)$community <- 1  # 所有节点为一个社区
  }

  return(g)
}

#' 计算反应网络并运行完整分析
#' @description 一站式函数，计算网络并运行完整分析
#' @param df 分子数据框
#' @param reaction_dict 反应字典（可选）
#' @param mass_tolerance 质量容差
#' @return 完整的网络分析结果
run_network_analysis <- function(df, reaction_dict = NULL, mass_tolerance = 5) {
  # 计算网络
  network_data <- calculate_reaction_network(df, reaction_dict, mass_tolerance)

  # 计算PageRank
  pagerank_result <- calculate_pagerank(network_data)

  # 分析网络属性
  network_properties <- analyze_network_properties(network_data)

  # 识别关键分子
  key_molecules <- identify_key_molecules(pagerank_result)

  # 计算模块性（如果igraph可用）
  if (requireNamespace("igraph", quietly = TRUE)) {
    modules <- calculate_network_modules(network_data)
  } else {
    modules <- NULL
  }

  # 计算相关性
  correlations <- list(
    pagerank_intensity = stats::cor(pagerank_result$pagerank, pagerank_result$intensity, method = "spearman"),
    pagerank_mass = stats::cor(pagerank_result$pagerank, pagerank_result$mass, method = "spearman")
  )

  # 返回完整结果
  list(
    network = network_data,
    pagerank = pagerank_result,
    properties = network_properties,
    key_molecules = key_molecules,
    modules = modules,
    correlations = correlations
  )
}