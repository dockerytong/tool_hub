# ==============================================================================
# mod_ml.R - 机器学习模块 (Random Forest)
# ==============================================================================

mod_ml_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "机器学习",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                h5("模型设置"),
                radioButtons(ns("grp_mode"), "分组来源：", choices = c("上传文件" = "upload", "手动输入" = "manual")),
                conditionalPanel(condition = "input.grp_mode == 'upload'", ns = ns, fileInput(ns("meta_upload"), "上传分组表", accept = ".csv")),
                conditionalPanel(condition = "input.grp_mode == 'manual'", ns = ns, div(style = "max-height: 200px; overflow-y: auto;", uiOutput(ns("manual_grp_ui"))), actionButton(ns("btn_apply_grp"), "应用分组", class = "btn-xs btn-success")),
                hr(),
                sliderInput(ns("n_tree"), "决策树数量 (ntree)", min = 100, max = 2000, value = 500, step = 100),
                actionButton(ns("btn_run"), "训练模型", class = "btn-primary", icon = icon("brain")),
                ui_display_settings(ns, default_w = 900, default_h = 600), # 新增
                ui_export_settings(ns, default_w = 8, default_h = 8),
                hr(),
                downloadButton(ns("download_csv"), "下载标志物表")
            ),
            mainPanel(
                width = 9,
                fluidRow(
                    column(
                        4,
                        div(
                            class = "well",
                            h4("模型准确率 (OOB)"),
                            h2(textOutput(ns("accuracy_text")), style = "color: #28a745; font-weight: bold;")
                        )
                    ),
                    column(
                        8,
                        div(
                            class = "alert alert-info",
                            h5(icon("info-circle"), "随机森林 (Random Forest)"),
                            p("该算法通过构建数百棵决策树来寻找能最好区分不同分组的分子。"),
                            tags$ul(
                                tags$li(strong("Mean Decrease Accuracy:"), " 衡量该分子对分类准确率的贡献。值越大，说明该分子越是区分组别的关键“标志物”。"),
                                tags$li("此分析需要至少两组，且每组建议有 3 个以上样品。")
                            )
                        )
                    )
                ),
                hr(),
                uiOutput(ns("plot_container")),
                hr(),
                h5("Top 标志物详情"),
                tableOutput(ns("table"))
            )
        )
    )
}

mod_ml_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        ns <- session$ns

        meta_data <- reactiveVal(NULL)
        rf_res <- reactiveVal(NULL)

        # ---- 分组逻辑 (复用) ----
        observeEvent(input$meta_upload, {
            req(input$meta_upload)
            tryCatch(
                {
                    df <- readr::read_csv(input$meta_upload$datapath, show_col_types = FALSE)
                    colnames(df)[1:2] <- c("Sample", "Group")
                    meta_data(df)
                },
                error = function(e) showNotification("分组读取失败", type = "error")
            )
        })

        output$manual_grp_ui <- renderUI({
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            lapply(seq_along(samples), function(i) {
                val <- if (!is.null(meta_data())) meta_data()$Group[meta_data()$Sample == samples[i]][1] else "Group1"
                textInput(ns(paste0("grp_", i)), samples[i], value = val)
            })
        })

        observeEvent(input$btn_apply_grp, {
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            grps <- sapply(seq_along(samples), function(i) input[[paste0("grp_", i)]])
            meta_data(data.frame(Sample = samples, Group = grps))
            showNotification("分组已应用", type = "message")
        })

        # ---- 训练模型 ----
        observeEvent(input$btn_run, {
            req(rv$processed_data, meta_data())

            # 检查分组数
            if (length(unique(meta_data()$Group)) < 2) {
                showNotification("至少需要 2 个不同的分组", type = "error")
                return()
            }

            withProgress(message = "训练随机森林模型...", detail = "这可能需要一点时间", {
                tryCatch(
                    {
                        res <- run_random_forest(rv$processed_data, meta_data(), n_tree = input$n_tree)
                        rf_res(res)
                    },
                    error = function(e) {
                        showNotification(paste("训练失败:", e$message), type = "error")
                    }
                )
            })
        })

        # ---- 输出 ----
        output$accuracy_text <- renderText({
            req(rf_res())
            paste0(rf_res()$accuracy, "%")
        })

        plot_reactive <- reactive({
            req(rf_res())
            plot_rf_importance(rf_res()$importance)
        })
        render_plot_container(output, session$ns, input)

        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        output$table <- renderTable({
            req(rf_res())
            rf_res()$importance %>%
                dplyr::select(Formula, Category, MeanDecreaseAccuracy, MW, OC, HC) %>%
                dplyr::mutate(across(where(is.numeric), ~ round(.x, 3)))
        })

        filename_base <- reactive({
            "RandomForest_Importance"
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)

        output$download_csv <- downloadHandler(
            filename = function() "Biomarkers.csv",
            content = function(file) readr::write_csv(rf_res()$importance, file)
        )
    })
}
