# ==============================================================================
# utils_helpers.R - 通用工具函数 (重构版 - 标准化)
# ==============================================================================

# ---- 新增：标准化验证函数 ----

#' 数据量验证函数
#' @param data 要验证的数据框
#' @param min_rows 最小行数要求
#' @param context 上下文描述
#' @param type 通知类型
#' @return 逻辑值，是否通过验证
validate_sufficient_data <- function(data, min_rows = 10, context = "分析", type = "warning") {
  if (is.null(data) || nrow(data) < min_rows) {
    showNotification(
      sprintf("数据量不足：需要≥%d行数据进行%s", min_rows, context),
      type = type
    )
    return(FALSE)
  }
  return(TRUE)
}

#' 样品数据过滤器
#' @param data 原始数据
#' @param sample 样品名称
#' @param category 类别过滤器（可选）
#' @param all_categories 是否包含所有类别
#' @return 过滤后的数据框
filter_sample_data <- function(data, sample, category = NULL, all_categories = TRUE) {
  if (is.null(data) || !"Sample" %in% colnames(data)) {
    return(NULL)
  }
  
  result <- data %>% dplyr::filter(Sample == sample)
  
  if (!all_categories && !is.null(category) && category != "All Categories" && "Category" %in% colnames(result)) {
    result <- result %>% dplyr::filter(Category == category)
  }
  
  return(result)
}

#' 通用样品选择器UI
#' @param ns 命名空间函数
#' @param samples 样品列表
#' @param inputId 输入ID
#' @param label 标签文本
#' @param selected 默认选择
ui_sample_selector <- function(ns, samples, inputId = "sample", label = "选择样品：", selected = NULL) {
  if (is.null(selected) && length(samples) > 0) {
    selected <- samples[1]
  }
  
  selectInput(ns(inputId), label, choices = samples, selected = selected)
}

#' 通用分析信息面板
#' @param ns 命名空间函数
#' @param title 面板标题
#' @param items 信息项列表（每个item包含label和description）
#' @param icon 图标名称
#' @param class CSS类名
ui_analysis_info_panel <- function(ns, title, items, icon = "info-circle", class = "alert-info") {
  div(
    class = paste("alert", class),
    style = "margin-top: 20px;",
    h5(icon(icon), title),
    tags$ul(
      lapply(items, function(item) {
        tags$li(strong(item$label), item$description)
      })
    )
  )
}

#' 通用文件命名函数
#' @param module 模块名称
#' @param params 参数字符串向量
#' @param separator 分隔符
#' @return 格式化文件名（不含扩展名）
generate_filename <- function(module, params = NULL, separator = "_") {
  parts <- c(module)
  if (!is.null(params)) {
    valid_params <- params[!sapply(params, is.null) & params != ""]
    if (length(valid_params) > 0) {
      parts <- c(parts, valid_params)
    }
  }
  paste(parts, collapse = separator)
}

# ---- UI 复用组件 ----

#' [修改] 网页显示设置 UI (含宽度和高度)
ui_display_settings <- function(ns, default_w = 1000, default_h = 600) {
    tagList(
        hr(),
        h5("显示设置 (仅网页)"),
        fluidRow(
            column(6, sliderInput(ns("disp_w"), "显示宽度 (px):", min = 400, max = 2500, value = default_w, step = 50)),
            column(6, sliderInput(ns("disp_h"), "显示高度 (px):", min = 400, max = 2000, value = default_h, step = 50))
        ),
        helpText("提示：如果宽度超出屏幕，下方会出现滚动条。")
    )
}

#' [原有] 导出设置 UI
ui_export_settings <- function(ns, default_w = 8, default_h = 6) {
    tagList(
        hr(),
        h5("导出设置 (下载用)"),
        fluidRow(
            column(6, numericInput(ns("width"), "宽 (in)", value = default_w, min = 2, step = 0.5)),
            column(6, numericInput(ns("height"), "高 (in)", value = default_h, min = 2, step = 0.5))
        ),
        downloadButton(ns("download_pdf"), "下载 PDF", class = "btn-sm"),
        downloadButton(ns("download_png"), "下载 PNG", class = "btn-sm")
    )
}

# ---- Server 复用逻辑 ----

#' [新增] 动态绘图容器生成器
#' @description 自动生成带滚动条的 plotOutput，并绑定宽高滑块
#' @param ns 命名空间函数
#' @param input 模块 input
#' @param output_id plot 的 ID (通常为 "plot")
render_plot_container <- function(output, ns, input, output_id = "plot") {
    output$plot_container <- renderUI({
        req(input$disp_w, input$disp_h)

        # 使用 div 包裹，实现 overflow 滚动
        div(
            style = "overflow-x: auto; overflow-y: hidden; width: 100%; border: 1px solid #eee;",
            plotOutput(ns(output_id),
                width = paste0(input$disp_w, "px"),
                height = paste0(input$disp_h, "px")
            )
        )
    })
}

#' [修改] 安全绘图渲染器 (支持动态宽高)
render_safe_plot <- function(plot_reactive, width_func = NULL, height_func = NULL, ...) {
    renderPlot(
        {
            p <- plot_reactive()
            if (is.null(p)) {
                plot.new()
                text(0.5, 0.5, "无数据 / 等待输入", cex = 1.5, col = "grey60")
            } else {
                print(p)
            }
        },
        res = 96,
        width = width_func,
        height = height_func,
        ...
    )
}

#' [原有] 下载处理器
setup_download_handlers <- function(output, input, plot_reactive, filename_base, dpi = 300) {
    output$download_pdf <- downloadHandler(
        filename = function() {
            base <- if (is.reactive(filename_base)) filename_base() else filename_base
            paste0(base, ".pdf")
        },
        content = function(file) {
            tryCatch(
                {
                    cairo_pdf(file, width = input$width, height = input$height)
                    p <- plot_reactive()
                    if (!is.null(p)) print(p)
                    dev.off()
                },
                error = function(e) dev.off()
            )
        }
    )

    output$download_png <- downloadHandler(
        filename = function() {
            base <- if (is.reactive(filename_base)) filename_base() else filename_base
            paste0(base, ".png")
        },
        content = function(file) {
            tryCatch(
                {
                    ragg::agg_png(file, width = input$width, height = input$height, units = "in", res = dpi)
                    p <- plot_reactive()
                    if (!is.null(p)) print(p)
                    dev.off()
                },
                error = function(e) dev.off()
            )
        }
    )
}

#' [原有] 自适应高度计算器 (保留备用)
calc_auto_height <- function(session, output_id, is_facet = FALSE, n_samples = 1, ncol = 3, ratio = 0.8) {
    w <- session$clientData[[paste0("output_", output_id, "_width")]]
    if (is.null(w) || w == 0) {
        return(400)
    }
    if (!is_facet) {
        return(w * ratio)
    }
    n_rows <- ceiling(n_samples / ncol)
    row_height <- (w / ncol) * ratio
    return(row_height * n_rows * 1.15)
}
