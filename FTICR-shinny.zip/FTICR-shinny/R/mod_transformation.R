# ==============================================================================
# mod_transformation.R - 转化分析模块 (修复布局覆盖问题)
# ==============================================================================

mod_transformation_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "转化分析",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                h5("数据选择"),
                uiOutput(ns("sample_selector")),
                selectInput(ns("category_filter"), "仅分析特定类别：",
                    choices = c("All Categories", names(VK_COLORS)),
                    selected = "All Categories"
                ),
                helpText("选择 'Lignin-like' 可聚焦木质素降解过程。"),
                hr(),
                h5("分析参数"),
                sliderInput(ns("top_n"), "分析 Top N 丰度分子：",
                    min = 100, max = 1000, value = 500, step = 50
                ),
                helpText("注意：构建网络非常耗时，建议 Top N < 500"),
                numericInput(ns("tolerance"), "质量误差 (ppm)：", value = 1.0, min = 0.1, max = 5.0),
                actionButton(ns("btn_run"), "开始分析", class = "btn-danger", icon = icon("project-diagram")),
                hr(),
                h5("可视化设置"),
                radioButtons(ns("viz_type"), "图表类型：",
                    choices = c("统计柱状图" = "bar", "网络拓扑图" = "network"),
                    selected = "bar"
                ),
                conditionalPanel(
                    condition = sprintf("input['%s'] == 'network'", ns("viz_type")),
                    selectInput(ns("net_color"), "节点着色：",
                        choices = c("化学类别" = "Category", "模块(聚类)" = "community", "O/C" = "OC", "H/C" = "HC")
                    ),
                    selectInput(ns("net_layout"), "布局算法：",
                        choices = c("Fruchterman-Reingold" = "fr", "Kamada-Kawai" = "kk", "Nicely" = "nicely")
                    )
                ),
                conditionalPanel(
                    condition = sprintf("input['%s'] == 'bar'", ns("viz_type")),
                    radioButtons(ns("bar_mode"), "显示模式：",
                        choices = c("绝对计数" = "count", "相对比例" = "percent"), selected = "count"
                    ),
                    checkboxInput(ns("hide_meth"), "隐藏 Methylation (+CH2)", value = FALSE)
                ),

                # [修改 1] 使用新的显示设置 (含宽度)
                ui_display_settings(ns, default_w = 1000, default_h = 600),
                ui_export_settings(ns, default_w = 10, default_h = 8),
                hr(),
                downloadButton(ns("download_csv"), "下载边列表")
            ),
            mainPanel(
                width = 9,
                # [修改 2] 使用容器占位符
                uiOutput(ns("plot_container")),

                # 动态解读文本
                uiOutput(ns("interpretation_text")),
                hr(),
                h5("转化统计详情"),
                tableOutput(ns("table"))
            )
        )
    )
}

mod_transformation_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 使用统一的命名空间处理 - 直接使用 session$ns，不重新定义 ns 变量

        output$sample_selector <- renderUI({
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            ui_sample_selector(session$ns, samples, "sample", "选择样品：")
        })

        # 统一的数据过滤逻辑 - 使用reactive确保df_sub可用
        df_sub <- reactive({
            req(rv$processed_data, input$sample)
            filter_sample_data(rv$processed_data, input$sample, input$category_filter, input$category_filter == "All Categories")
        })

        # 触发分析按钮事件 - 仅用于触发reactive计算
        observeEvent(input$btn_run, {
            req(df_sub())
            if (!validate_sufficient_data(df_sub(), 10, "转化网络分析")) {
                return()
            }
            # reactive会自动重新计算，这里只需要触发验证
        })
        
        # 统一的响应式逻辑 - 使用单个reactive替代多个reactiveVal
        analysis_results <- reactive({
            req(input$btn_run, df_sub())
            
            if (!validate_sufficient_data(df_sub(), 10, "转化网络分析")) {
                return(NULL)
            }
            
            withProgress(message = "正在构建转化网络...", value = 0, {
                incProgress(0.3, detail = "计算质量差矩阵...")
                res <- calculate_transformations(df_sub(), top_n = input$top_n, tolerance_ppm = input$tolerance)
                
                if (is.null(res) || nrow(res) == 0) {
                    showNotification("未找到匹配的转化关系", type = "warning")
                    return(NULL)
                }
                
                incProgress(0.4, detail = "构建网络拓扑...")
                g <- build_transformation_network(res, df_sub())
                
                list(transformations = res, network = g)
            })
        })
        
        plot_reactive <- reactive({
            req(analysis_results())
            
            if (input$viz_type == "bar") {
                plot_data <- analysis_results()$transformations
                if (input$hide_meth) plot_data <- plot_data %>% dplyr::filter(Transformation != "Methylation")
                if (!validate_sufficient_data(plot_data, 1, "柱状图绘制")) {
                    return(NULL)
                }

                stats <- plot_data %>% dplyr::count(Transformation)
                p <- ggplot2::ggplot(stats, ggplot2::aes(x = reorder(Transformation, n), y = n, fill = Transformation)) +
                    ggplot2::coord_flip() +
                    ggplot2::scale_fill_brewer(palette = "Set2") +
                    cowplot::theme_half_open(font_size = 12) +
                    ggplot2::theme(legend.position = "none")

                if (input$bar_mode == "percent") {
                    p <- p + ggplot2::geom_col(ggplot2::aes(y = n / sum(n) * 100), width = 0.7, color = "black", linewidth = 0.2) +
                        ggplot2::labs(x = NULL, y = "Percentage (%)", title = "Transformation Proportion")
                } else {
                    p <- p + ggplot2::geom_col(width = 0.7, color = "black", linewidth = 0.2) +
                        ggplot2::labs(x = NULL, y = "Count", title = "Transformation Frequency")
                }
                return(p)
            } else {
                req(analysis_results()$network)
                plot_transformation_network(
                    analysis_results()$network,
                    color_by = input$net_color,
                    layout = input$net_layout
                )
            }
        })

        # 使用标准化的容器和绘图函数
        render_plot_container(output, session$ns, input)

        # [修改 4] 绘图渲染 (传入宽高函数)
        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        # 标准化的解释文本 - 使用新的分析结果结构
        output$interpretation_text <- renderUI({
            req(analysis_results())
            
            trans_data <- analysis_results()$transformations
            net_data <- analysis_results()$network
            
            counts <- table(trans_data$Transformation)
            total <- sum(counts)
            get_cnt <- function(name) {
                if (name %in% names(counts)) as.numeric(counts[name]) else 0
            }

            n_meth <- get_cnt("Methylation")
            n_ox <- get_cnt("Oxidation")
            n_cond <- get_cnt("Condensation")
            n_hydro <- get_cnt("Hydrogenation")

            pct_meth <- n_meth / total
            pct_ox <- n_ox / total

            # 标准化的信息项构建
            info_items <- list()
            
            # 网络拓扑信息
            if (!is.null(net_data)) {
                n_nodes <- igraph::gorder(net_data)
                n_edges <- igraph::gsize(net_data)
                avg_deg <- round(mean(igraph::degree(net_data)), 2)
                
                info_items <- append(info_items, list(
                    list(label = "网络拓扑:", description = sprintf("包含 %d 个节点 (分子) 和 %d 条边 (转化路径)", n_nodes, n_edges)),
                    list(label = "平均度:", description = sprintf("%.2f，平均每个分子与 %.2f 个其他分子有生化联系", avg_deg, avg_deg))
                ))
            }

            analysis_content <- tagList()

            if (pct_meth > 0.5) {
                analysis_content <- tagList(
                    analysis_content,
                    tags$li(
                        strong("结构稳定性主导 (High Methylation): "),
                        paste0("Methylation 占比高达 ", round(pct_meth * 100, 1), "%。"),
                        "说明 DOM 分子主要以同系物（烷基链长度差异）形式存在。在尾矿/土壤中，这通常代表",
                        strong("脂类、蜡质或脂肪族碳骨架"), "的积累。"
                    )
                )
            } else if (pct_ox > 0.2) {
                analysis_content <- tagList(
                    analysis_content,
                    tags$li(
                        strong("氧化降解活跃 (High Oxidation): "),
                        "检测到高频的 +O 转化。这指示了强烈的", strong("有氧微生物呼吸"),
                        "或", strong("光化学氧化"), "过程。"
                    )
                )
            }

            if (n_cond > 0) {
                cond_ratio <- round(n_cond / (n_ox + 0.1), 2)
                desc <- if (cond_ratio > 1) "缩合作用强于氧化，提示腐殖化(Humification)或非生物聚合过程占优。" else "缩合作用存在，但弱于氧化降解。"
                analysis_content <- tagList(
                    analysis_content,
                    tags$li(
                        strong("腐殖化/聚合 (Condensation): "),
                        paste0("检测到 ", n_cond, " 次脱水缩合信号 (+H2O)。"), desc
                    )
                )
            }

            if (n_hydro > n_ox) {
                analysis_content <- tagList(
                    analysis_content,
                    tags$li(
                        strong("还原/饱和化环境 (High Hydrogenation): "),
                        "+H2 信号显著。这可能暗示土壤处于", strong("还原环境 (缺氧)"),
                        "或微生物正在进行脂肪酸的合成/改性。"
                    )
                )
            }

            filter_advice <- tagList()
            if (input$category_filter == "All Categories" && pct_meth > 0.6) {
                filter_advice <- div(
                    style = "margin-top:10px; color:#d9534f;", icon("exclamation-circle"),
                    strong(" 建议操作："), "Methylation 信号过强，掩盖了其他过程。请尝试：",
                    tags$ul(
                        tags$li("勾选 '隐藏 Methylation' 查看次级过程。"),
                        tags$li("在上方 '仅分析特定类别' 中选择 'Lignin-like' (看降解) 或 'Protein-like' (看活性)。")
                    )
                )
            }

            div(
                class = "alert alert-info",
                style = "margin-top: 20px; border-left: 5px solid #5bc0de;",
                h4(icon("microscope"), " 生态与地球化学解读"),
                p("基于当前参数的自动化分析："),
                tags$ul(analysis_content),
                filter_advice,
                hr(),
                p(
                    style = "font-size: 0.9em; color: #666;",
                    em("注：转化网络基于质量差推断 (Mass Difference Analysis)。高频转化代表该化学过程在分子库中的普遍性。")
                )
            )
        })

        output$table <- renderTable({
            req(analysis_results())
            analysis_results()$transformations %>%
                dplyr::count(Transformation) %>%
                dplyr::arrange(desc(n)) %>%
                dplyr::mutate(Percentage = paste0(round(n / sum(n) * 100, 1), "%")) %>%
                dplyr::rename(转化类型 = Transformation, 次数 = n, 占比 = Percentage)
        })

        filename_base <- reactive({
            paste0("Trans_", input$viz_type, "_", input$sample)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)

        output$download_csv <- downloadHandler(
            filename = function() "Transformation_Edges.csv",
            content = function(file) readr::write_csv(analysis_results()$transformations, file)
        )
    })
}
