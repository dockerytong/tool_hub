# ==============================================================================
# fct_chemistry.R - 化学计算函数
# ==============================================================================

#' VK 分类
assign_vk_category <- function(oc, hc) {
    dplyr::case_when(
        oc >= 0.00 & oc <= 0.30 & hc >= 1.5 & hc <= 2.0 ~ "Lipid-like",
        oc >= 0.30 & oc <= 0.67 & hc >= 1.5 & hc <= 2.2 ~ "Protein-like",
        oc >= 0.67 & oc <= 1.20 & hc >= 1.5 & hc <= 2.2 ~ "Carboh.-like",
        oc >= 0.10 & oc <= 0.67 & hc >= 0.7 & hc <= 1.5 ~ "Lignin-like",
        oc >= 0.67 & oc <= 1.20 & hc >= 0.5 & hc <= 1.5 ~ "Tannin-like",
        oc >= 0.00 & oc <= 0.67 & hc >= 0.2 & hc <= 0.7 ~ "Cond. arom.",
        oc >= 0.00 & oc <= 0.10 & hc >= 0.7 & hc <= 1.5 ~ "Unsaturated",
        TRUE ~ "Other"
    )
}

#' 计算化学指标
calculate_chem_indices <- function(df) {
    df %>%
        dplyr::mutate(
            MW = C * 12.00000 + H * 1.00783 + O * 15.99491 + N * 14.00307 + S * 31.97207,
            DBE = 1 + C - 0.5 * H + 0.5 * N,
            DBE_C = ifelse(C > 0, DBE / C, 0),
            AI_mod = pmax((1 + C - 0.5 * O - S - 0.5 * N - 0.5 * H) / (C - 0.5 * O - S - N), 0),
            AI_mod = ifelse(is.infinite(AI_mod) | is.na(AI_mod), 0, AI_mod),
            NOSC = 4 - ((4 * C + H - 3 * N - 2 * O - 2 * S) / C),
            Gibbs = 60.3 - 28.5 * NOSC,
            NC = ifelse(C > 0, N / C, 0),
            SC = ifelse(C > 0, S / C, 0)
        )
}

#' 处理上传的 CSV 数据
process_uploaded_data <- function(file_list) {
    df_list <- lapply(seq_len(nrow(file_list)), function(i) {
        sample_name <- tools::file_path_sans_ext(file_list$name[i])
        dt <- data.table::fread(
            file_list$datapath[i],
            select = c("sum formula", "Observed Intens", "C", "H", "N", "O", "S")
        )
        dt %>%
            dplyr::rename(Formula = `sum formula`, Abundance = `Observed Intens`) %>%
            dplyr::mutate(Sample = sample_name, Abundance = as.numeric(Abundance)) %>%
            dplyr::filter(!is.na(Formula), Formula != "", C > 0)
    })

    df_raw <- dplyr::bind_rows(df_list) %>%
        dplyr::group_by(Sample, Formula, C, H, N, O, S) %>%
        dplyr::summarise(Abundance = sum(Abundance, na.rm = TRUE), .groups = "drop")

    df_raw %>%
        dplyr::mutate(
            H = H + 1,
            HC = H / C,
            OC = O / C,
            Category = assign_vk_category(OC, HC),
            Category = factor(Category, levels = names(VK_COLORS))
        ) %>%
        calculate_chem_indices()
}

#' TIC 标准化
normalize_tic <- function(df, scale_to = 100) {
    df %>%
        dplyr::group_by(Sample) %>%
        dplyr::mutate(
            total_intensity = sum(Abundance, na.rm = TRUE),
            Abundance = ifelse(total_intensity > 0, (Abundance / total_intensity) * scale_to, Abundance)
        ) %>%
        dplyr::ungroup() %>%
        dplyr::select(-total_intensity)
}

#' 背景扣除
subtract_background <- function(df, bg_sample) {
    if (is.null(bg_sample) || bg_sample == "" || !bg_sample %in% unique(df$Sample)) {
        return(df)
    }

    bg_data <- df %>%
        dplyr::filter(Sample == bg_sample) %>%
        dplyr::select(Formula, bg_Abundance = Abundance)

    df %>%
        dplyr::filter(Sample != bg_sample) %>%
        dplyr::left_join(bg_data, by = "Formula") %>%
        dplyr::mutate(
            bg_Abundance = tidyr::replace_na(bg_Abundance, 0),
            Abundance = pmax(Abundance - bg_Abundance, 0)
        ) %>%
        dplyr::select(-bg_Abundance) %>%
        dplyr::filter(Abundance > 0)
}

#' 计算 Alpha 多样性
calculate_alpha_diversity <- function(df) {
    mat_wide <- df %>%
        dplyr::select(Sample, Formula, Abundance) %>%
        tidyr::pivot_wider(names_from = Formula, values_from = Abundance, values_fill = 0) %>%
        tibble::column_to_rownames("Sample") %>%
        as.matrix()

    data.frame(
        Sample = rownames(mat_wide),
        Richness = vegan::specnumber(mat_wide),
        Shannon = vegan::diversity(mat_wide, index = "shannon"),
        Simpson = vegan::diversity(mat_wide, index = "simpson"),
        Pielou = vegan::diversity(mat_wide, index = "shannon") / log(vegan::specnumber(mat_wide))
    ) %>%
        dplyr::mutate(Pielou = ifelse(is.nan(Pielou), 0, Pielou))
}

#' PCoA 分析 (支持多种距离)
calculate_pcoa <- function(df, method = "bray") {
    # 转换为宽格式矩阵
    mat_wide <- df %>%
        dplyr::select(Sample, Formula, Abundance) %>%
        tidyr::pivot_wider(names_from = Formula, values_from = Abundance, values_fill = 0) %>%
        tibble::column_to_rownames("Sample") %>%
        as.matrix()

    # 特殊处理：Jaccard 通常用于 Presence/Absence
    is_binary <- (method == "jaccard")

    # 计算距离矩阵
    # tryCatch 防止某些极端情况下距离计算失败
    tryCatch(
        {
            dist_mat <- vegan::vegdist(mat_wide, method = method, binary = is_binary)
        },
        error = function(e) {
            stop(paste("距离计算失败:", e$message))
        }
    )

    # PCoA (MDS)
    pcoa_result <- cmdscale(dist_mat, k = 2, eig = TRUE)

    # 提取坐标
    pcoa_points <- as.data.frame(pcoa_result$points) %>%
        tibble::rownames_to_column("Sample") %>%
        dplyr::rename(PCoA1 = V1, PCoA2 = V2)

    # 提取解释率
    eig_vals <- pcoa_result$eig
    # 只取正特征值计算百分比
    eig_vals <- eig_vals[eig_vals > 0]
    eig_pct <- round(eig_vals / sum(eig_vals) * 100, 1)

    list(points = pcoa_points, eig_pct = eig_pct, method = method)
}

#' 计算加权平均性质
calculate_weighted_averages <- function(df) {
    df %>%
        dplyr::filter(Abundance > 0) %>%
        dplyr::group_by(Sample) %>%
        dplyr::summarise(
            WA_MW = weighted.mean(MW, Abundance, na.rm = TRUE),
            WA_OC = weighted.mean(OC, Abundance, na.rm = TRUE),
            WA_HC = weighted.mean(HC, Abundance, na.rm = TRUE),
            WA_DBE = weighted.mean(DBE, Abundance, na.rm = TRUE),
            WA_DBE_C = weighted.mean(DBE_C, Abundance, na.rm = TRUE),
            WA_AI = weighted.mean(AI_mod, Abundance, na.rm = TRUE),
            WA_NOSC = weighted.mean(NOSC, Abundance, na.rm = TRUE),
            WA_Gibbs = weighted.mean(Gibbs, Abundance, na.rm = TRUE),
            .groups = "drop"
        )
}

#' 计算活性指数
calculate_lability <- function(df) {
    df_lability <- df %>%
        dplyr::mutate(
            Lability_Type = dplyr::case_when(
                HC > 1.5 & OC < 0.5 ~ "Labile",
                AI_mod >= 0.5 ~ "Recalcitrant",
                TRUE ~ "Intermediate"
            )
        )

    df_summary <- df_lability %>%
        dplyr::filter(Abundance > 0) %>%
        dplyr::group_by(Sample, Lability_Type) %>%
        dplyr::summarise(Total_Abund = sum(Abundance, na.rm = TRUE), .groups = "drop") %>%
        dplyr::group_by(Sample) %>%
        dplyr::mutate(Percent = Total_Abund / sum(Total_Abund) * 100) %>%
        dplyr::ungroup()

    df_index <- df_summary %>%
        tidyr::pivot_wider(
            id_cols = Sample, names_from = Lability_Type,
            values_from = c(Total_Abund, Percent), values_fill = 0
        ) %>%
        dplyr::mutate(
            Lability_Index = Total_Abund_Labile / (Total_Abund_Labile + Total_Abund_Recalcitrant + 0.001)
        )

    list(detail = df_summary, index = df_index)
}

#' CRAM 分类
assign_cram_category <- function(df) {
    df %>%
        dplyr::mutate(
            is_CRAM = dplyr::case_when(
                (DBE_C >= 0.30 & DBE_C <= 0.68) & (OC >= 0.20 & OC <= 0.90) & (HC >= 0.70 & HC <= 1.50) ~ "CRAM",
                TRUE ~ "Non-CRAM"
            )
        )
}

#' 计算 CRAM 比例
calculate_cram_abundance <- function(df) {
    df_cram <- assign_cram_category(df)

    df_cram %>%
        dplyr::filter(Abundance > 0) %>%
        dplyr::group_by(Sample, is_CRAM) %>%
        dplyr::summarise(Count = dplyr::n(), Total_Abund = sum(Abundance, na.rm = TRUE), .groups = "drop") %>%
        dplyr::group_by(Sample) %>%
        dplyr::mutate(Count_Pct = Count / sum(Count) * 100, Abund_Pct = Total_Abund / sum(Total_Abund) * 100) %>%
        dplyr::ungroup()
}

#' 差异分析
perform_diff_analysis <- function(df, group_a_samples, group_b_samples) {
    df %>%
        dplyr::mutate(
            Present_A = Sample %in% group_a_samples & Abundance > 0,
            Present_B = Sample %in% group_b_samples & Abundance > 0
        ) %>%
        dplyr::group_by(Formula, C, H, O, N, S, HC, OC, Category, MW, DBE, NOSC) %>%
        dplyr::summarise(
            Count_A = sum(Present_A), Count_B = sum(Present_B),
            Mean_Abund_A = mean(Abundance[Sample %in% group_a_samples], na.rm = TRUE),
            Mean_Abund_B = mean(Abundance[Sample %in% group_b_samples], na.rm = TRUE),
            .groups = "drop"
        ) %>%
        dplyr::mutate(
            Mean_Abund_A = tidyr::replace_na(Mean_Abund_A, 0),
            Mean_Abund_B = tidyr::replace_na(Mean_Abund_B, 0),
            Diff_Status = dplyr::case_when(
                Count_A >= 2 & Count_B == 0 ~ "Group A only",
                Count_B >= 2 & Count_A == 0 ~ "Group B only",
                Count_A >= 1 & Count_B >= 1 ~ "Shared",
                TRUE ~ "Rare"
            )
        )
}

#' 读取环境因子数据
read_env_data <- function(file_path, file_type = "auto") {
    if (file_type == "auto") {
        ext <- tools::file_ext(file_path)
        file_type <- ifelse(ext %in% c("xlsx", "xls"), "excel", "csv")
    }
    if (file_type == "excel") readxl::read_excel(file_path) else readr::read_csv(file_path, show_col_types = FALSE)
}

#' 合并 DOM 指标与环境因子
merge_dom_env <- function(alpha_div, wa_data, lability_data, cram_data, env_data) {
    cram_pct <- cram_data %>%
        dplyr::filter(is_CRAM == "CRAM") %>%
        dplyr::select(Sample, CRAM_Pct = Abund_Pct)

    lability_idx <- lability_data$index %>% dplyr::select(Sample, Lability_Index)

    dom_data <- alpha_div %>%
        dplyr::left_join(wa_data, by = "Sample") %>%
        dplyr::left_join(lability_idx, by = "Sample") %>%
        dplyr::left_join(cram_pct, by = "Sample")

    env_data <- env_data %>% dplyr::rename_with(~"Sample", .cols = 1)

    dom_data %>% dplyr::inner_join(env_data, by = "Sample")
}

#' 计算相关性矩阵
calculate_correlation <- function(merged_data, method = "spearman") {
    numeric_data <- merged_data %>%
        dplyr::select(where(is.numeric)) %>%
        dplyr::select(where(~ !all(is.na(.))))

    cor_mat <- cor(numeric_data, use = "pairwise.complete.obs", method = method)

    n_cols <- ncol(numeric_data)
    p_mat <- matrix(NA, n_cols, n_cols)
    rownames(p_mat) <- colnames(numeric_data)
    colnames(p_mat) <- colnames(numeric_data)

    for (i in 1:n_cols) {
        for (j in 1:n_cols) {
            if (i != j) {
                test <- cor.test(numeric_data[[i]], numeric_data[[j]], method = method)
                p_mat[i, j] <- test$p.value
            }
        }
    }

    list(cor = cor_mat, p = p_mat)
}

#' 汇总导出数据
export_summary_data <- function(processed_data, alpha_div, wa_data, lability_result, cram_data) {
    formula_summary <- processed_data %>%
        dplyr::group_by(Formula, C, H, O, N, S) %>%
        dplyr::summarise(n_Samples = dplyr::n_distinct(Sample), Mean_Abundance = mean(Abundance, na.rm = TRUE), .groups = "drop") %>%
        dplyr::left_join(
            processed_data %>% dplyr::select(Formula, HC, OC, Category, MW, DBE, NOSC, Gibbs, AI_mod) %>% dplyr::distinct(),
            by = "Formula"
        )

    cram_pct <- cram_data %>%
        dplyr::filter(is_CRAM == "CRAM") %>%
        dplyr::select(Sample, CRAM_Pct = Abund_Pct)

    sample_summary <- alpha_div %>%
        dplyr::left_join(wa_data, by = "Sample") %>%
        dplyr::left_join(lability_result$index %>% dplyr::select(Sample, Lability_Index), by = "Sample") %>%
        dplyr::left_join(cram_pct, by = "Sample")

    list(formula = formula_summary, sample = sample_summary)
}

#' 计算统计差异 (Volcano 数据)
#' @param df 处理后的数据框
#' @param group_a A组样品名称向量
#' @param group_b B组样品名称向量
#' @param method 检验方法 "wilcox" 或 "t.test"
#' @param p_threshold P值阈值 (默认0.05)
#' @param fc_threshold 差异倍数阈值 (默认1，即倍数差异>2)
calculate_stat_diff <- function(df, group_a, group_b, method = "wilcox", p_threshold = 0.05, fc_threshold = 1) {
    # 1. 筛选数据并转换为宽格式
    sub_df <- df %>%
        dplyr::filter(Sample %in% c(group_a, group_b)) %>%
        dplyr::select(Sample, Formula, Abundance)

    # 宽格式：行=Formula, 列=Sample
    mat <- sub_df %>%
        tidyr::pivot_wider(names_from = Sample, values_from = Abundance, values_fill = 0)

    # 2. 初始化结果存储
    formulas <- mat$Formula
    p_values <- numeric(length(formulas))
    log2fc <- numeric(length(formulas))

    # 提取两组数据矩阵
    mat_a <- as.matrix(mat[, group_a])
    mat_b <- as.matrix(mat[, group_b])

    # 3. 循环计算 (为了速度，这里用简单的循环，大数据量可考虑矩阵运算优化)
    for (i in seq_along(formulas)) {
        vals_a <- mat_a[i, ]
        vals_b <- mat_b[i, ]

        # 均值 (加小量防止除以0)
        mean_a <- mean(vals_a) + 1e-6
        mean_b <- mean(vals_b) + 1e-6

        # Log2 Fold Change (A / B)
        log2fc[i] <- log2(mean_a / mean_b)

        # 统计检验
        # 只有当两组都有非零值，或者差异足够大时才做检验
        if (sum(vals_a > 0) == 0 && sum(vals_b > 0) == 0) {
            p_values[i] <- 1
        } else {
            tryCatch(
                {
                    if (method == "wilcox") {
                        res <- wilcox.test(vals_a, vals_b, exact = FALSE)
                        p_values[i] <- res$p.value
                    } else {
                        res <- t.test(vals_a, vals_b)
                        p_values[i] <- res$p.value
                    }
                },
                error = function(e) {
                    p_values[i] <- 1
                }
            )
        }
    }

    # 4. 整理结果
    res_df <- data.frame(
        Formula = formulas,
        P_Value = p_values,
        Log2FC = log2fc
    ) %>%
        dplyr::mutate(
            FDR = p.adjust(P_Value, method = "fdr"),
            Significance = dplyr::case_when(
                P_Value < p_threshold & Log2FC > fc_threshold ~ "Enriched in A",
                P_Value < p_threshold & Log2FC < -fc_threshold ~ "Enriched in B",
                TRUE ~ "Not Sig"
            )
        ) %>%
        # 合并化学信息
        dplyr::left_join(
            df %>% dplyr::select(Formula, C, H, O, N, S, OC, HC, Category, MW) %>% dplyr::distinct(),
            by = "Formula"
        )

    return(res_df)
}

#' 计算转化网络
#' @param df 单个样品的数据框
#' @param top_n 只计算丰度最高的 N 个分子 (防止计算量过大)
#' @param tolerance_ppm 质量匹配误差 (ppm)
calculate_transformations <- function(df, top_n = 1000, tolerance_ppm = 1.0) {
    # 1. 筛选 Top N 分子
    df_sub <- df %>%
        dplyr::arrange(desc(Abundance)) %>%
        dplyr::slice_head(n = top_n) %>%
        dplyr::select(Formula, MW, Abundance)

    masses <- df_sub$MW
    formulas <- df_sub$Formula
    n <- length(masses)

    # 2. 计算两两质量差矩阵 (外积)
    # diff_mat[i, j] = mass[i] - mass[j]
    diff_mat <- outer(masses, masses, "-")

    # 只看正值 (避免重复和负值)
    diff_vals <- diff_mat[upper.tri(diff_mat)]

    # 记录索引
    idx <- which(upper.tri(diff_mat), arr.ind = TRUE)
    row_idx <- idx[, 1]
    col_idx <- idx[, 2]

    # 3. 匹配转化类型
    results_list <- list()

    for (i in 1:nrow(TRANSFORMATIONS)) {
        target_mass <- TRANSFORMATIONS$Mass[i]
        trans_name <- TRANSFORMATIONS$Name[i]

        # 计算 ppm 误差
        # error = |diff - target| / target * 1e6
        # 为了速度，我们先筛选大致范围，再精确计算

        lower_bound <- target_mass * (1 - tolerance_ppm * 1e-6)
        upper_bound <- target_mass * (1 + tolerance_ppm * 1e-6)

        match_idx <- which(diff_vals >= lower_bound & diff_vals <= upper_bound)

        if (length(match_idx) > 0) {
            results_list[[trans_name]] <- data.frame(
                Transformation = trans_name,
                Source_Formula = formulas[col_idx[match_idx]], # 质量小的
                Target_Formula = formulas[row_idx[match_idx]], # 质量大的
                Mass_Diff = diff_vals[match_idx]
            )
        }
    }

    # 4. 合并结果
    if (length(results_list) == 0) {
        return(NULL)
    }

    final_res <- dplyr::bind_rows(results_list)
    return(final_res)
}
