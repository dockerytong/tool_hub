#' 执行随机森林分析
#' @param df 处理后的数据框
#' @param group_df 分组数据框 (Sample, Group)
#' @param n_tree 树的数量
#' @return list(model, importance_df, confusion_matrix)
run_random_forest <- function(df, group_df, n_tree = 500) {
    # 依赖包: randomForest

    # 1. 数据准备：转宽格式 (Sample x Formula)
    mat <- df %>%
        dplyr::select(Sample, Formula, Abundance) %>%
        tidyr::pivot_wider(names_from = Formula, values_from = Abundance, values_fill = 0) %>%
        tibble::column_to_rownames("Sample")

    # 2. 对齐分组
    # 确保样品在分组表中存在
    common_samples <- intersect(rownames(mat), group_df$Sample)
    if (length(common_samples) < 6) stop("样品总数过少 (<6)，无法进行机器学习训练")

    mat <- mat[common_samples, ]
    group_vec <- group_df$Group[match(common_samples, group_df$Sample)]
    group_factor <- as.factor(group_vec)

    # 3. 运行随机森林
    set.seed(123) # 保证可重复性
    rf_model <- randomForest::randomForest(
        x = mat,
        y = group_factor,
        ntree = n_tree,
        importance = TRUE,
        proximity = TRUE
    )

    # 4. 提取重要性特征
    # MeanDecreaseAccuracy: 变量被剔除后模型准确率下降多少（越重要值越大）
    imp <- randomForest::importance(rf_model)
    imp_df <- as.data.frame(imp) %>%
        tibble::rownames_to_column("Formula") %>%
        dplyr::arrange(desc(MeanDecreaseAccuracy)) %>%
        dplyr::select(Formula, MeanDecreaseAccuracy, MeanDecreaseGini) %>%
        head(30) # 只取前 30 个最重要的

    # 关联化学属性
    imp_df <- imp_df %>%
        dplyr::left_join(
            df %>% dplyr::select(Formula, Category, MW, OC, HC) %>% dplyr::distinct(),
            by = "Formula"
        )

    list(
        model = rf_model,
        importance = imp_df,
        accuracy = round((1 - mean(rf_model$err.rate[, 1])) * 100, 2) # OOB 准确率
    )
}

#' 绘制特征重要性棒棒糖图
plot_rf_importance <- function(imp_df) {
    ggplot2::ggplot(imp_df, ggplot2::aes(x = reorder(Formula, MeanDecreaseAccuracy), y = MeanDecreaseAccuracy, color = Category)) +
        ggplot2::geom_segment(ggplot2::aes(xend = Formula, yend = 0), color = "grey") +
        ggplot2::geom_point(size = 3) +
        ggplot2::coord_flip() +
        ggplot2::scale_color_brewer(palette = "Set1") +
        ggplot2::labs(
            x = NULL,
            y = "Mean Decrease Accuracy",
            title = "Top 30 Biomarkers (Random Forest)",
            subtitle = "Features that best distinguish the groups"
        ) +
        cowplot::theme_half_open(font_size = 12)
}
