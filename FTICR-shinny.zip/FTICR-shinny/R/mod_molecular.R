# ==============================================================================
# mod_molecular.R - 分子特征模块 (完整版)
# ==============================================================================

mod_molecular_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "分子特征",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                radioButtons(ns("mode"), "显示模式：",
                    choices = c("单样品" = "single", "分面" = "facet"),
                    selected = "single"
                ),
                conditionalPanel(
                    condition = sprintf("input['%s'] == 'single'", ns("mode")),
                    uiOutput(ns("sample_selector"))
                ),
                conditionalPanel(
                    condition = sprintf("input['%s'] == 'facet'", ns("mode")),
                    numericInput(ns("facet_ncol"), "每行列数", value = 3, min = 1, max = 6)
                ),
                hr(),
                selectInput(ns("plot_type"), "图类型：",
                    choices = c(
                        "DBE vs C#" = "dbe_c", "KMD" = "kmd",
                        "分子量分布" = "mw", "NOSC vs MW" = "nosc",
                        "N/C vs O/C" = "nc_oc"
                    ),
                    selected = "dbe_c"
                ),
                ui_display_settings(ns, default_w = 800, default_h = 600),
                ui_export_settings(ns, default_w = 8, default_h = 6)
            ),
            mainPanel(
                uiOutput(ns("plot_container")),
                uiOutput(ns("info_panel"))
            )
        )
    )
}

mod_molecular_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 使用标准化的样品选择器
        output$sample_selector <- renderUI({
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            ui_sample_selector(session$ns, samples, "sample", "选择样品：")
        })

        # 标准化的响应式逻辑
        plot_reactive <- reactive({
            req(rv$processed_data, input$plot_type)
            if (!validate_sufficient_data(rv$processed_data, 1, "分子特征分析")) {
                return(NULL)
            }

            is_facet_supported <- input$plot_type %in% c("dbe_c", "kmd")

            if (input$mode == "facet" && is_facet_supported) {
                if (input$plot_type == "dbe_c") {
                    plot_dbe_c_facet(rv$processed_data, ncol = input$facet_ncol)
                } else {
                    plot_kmd_facet(rv$processed_data, ncol = input$facet_ncol)
                }
            } else {
                req(input$sample)
                switch(input$plot_type,
                    "dbe_c" = plot_dbe_c(rv$processed_data, input$sample),
                    "kmd" = plot_kmd(rv$processed_data, input$sample),
                    "mw" = plot_mw_distribution(rv$processed_data, input$sample),
                    "nosc" = plot_nosc_mw(rv$processed_data, input$sample),
                    "nc_oc" = plot_nc_oc(rv$processed_data, input$sample)
                )
            }
        })
        
        # 使用标准化的容器和绘图函数
        render_plot_container(output, session$ns, input)
        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        # 标准化的分析信息面板
        output$info_panel <- renderUI({
            req(rv$processed_data)
            
            plot_info <- switch(input$plot_type,
                "dbe_c" = list(
                    list(label = "DBE vs Carbon:", description = "展示不饱和度与碳数的关系，参考线 AI=0.5 和 AI=0.67 用于区分稠环芳烃"),
                    list(label = "应用:", description = "识别不同芳香性程度的化合物系列")
                ),
                "kmd" = list(
                    list(label = "KMD (Kendrick Mass Defect):", description = "用于识别同系物，水平排列的点阵代表相差CH2的同系物系列"),
                    list(label = "应用:", description = "快速识别化合物同系物，追踪生物地球化学过程")
                ),
                "mw" = list(
                    list(label = "分子量分布:", description = "分子量分布曲线，反映DOM的聚合程度"),
                    list(label = "应用:", description = "比较不同样品分子大小分布特征")
                ),
                "nosc" = list(
                    list(label = "NOSC (Nominal Oxidation State of Carbon):", description = "碳的平均氧化态，值越高氧化程度越高"),
                    list(label = "应用:", description = "评估有机质的氧化程度和生物利用度")
                ),
                "nc_oc" = list(
                    list(label = "N/C vs O/C:", description = "氮碳比与氧碳比的关系图"),
                    list(label = "应用:", description = "识别不同元素组成的化合物类别")
                )
            )
            
            ui_analysis_info_panel(session$ns, "图表解读", plot_info, icon = "info-circle")
        })

        # 使用标准化的文件命名
        filename_base <- reactive({
            suffix <- if (input$mode == "single") input$sample else "Facet"
            generate_filename(input$plot_type, suffix)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)
    })
}
