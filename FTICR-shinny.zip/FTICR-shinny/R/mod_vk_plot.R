# ==============================================================================
# mod_vk_plot.R - VK 图模块 (重构版)
# ==============================================================================

mod_vk_plot_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "VK 图",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                radioButtons(ns("mode"), "显示模式：", choices = c("单样品" = "single", "分面" = "facet"), selected = "single"),
                conditionalPanel(condition = sprintf("input['%s'] == 'single'", ns("mode")), uiOutput(ns("sample_selector"))),
                conditionalPanel(condition = sprintf("input['%s'] == 'facet'", ns("mode")), numericInput(ns("facet_ncol"), "每行列数", value = 3, min = 1, max = 6)),

                # 使用标准化的UI组件
                ui_display_settings(ns, default_w = 800, default_h = 600),
                ui_export_settings(ns, default_w = 6, default_h = 5)
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container"))
            )
        )
    )
}

mod_vk_plot_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 使用标准化的样品选择器
        output$sample_selector <- renderUI({
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            ui_sample_selector(session$ns, samples, "sample", "选择样品：")
        })

        # 标准化的响应式逻辑
        plot_reactive <- reactive({
            req(rv$processed_data)
            if (!validate_sufficient_data(rv$processed_data, 1, "VK图绘制")) {
                return(NULL)
            }
            
            if (input$mode == "single") {
                req(input$sample)
                plot_vk(rv$processed_data, input$sample)
            } else {
                plot_vk_facet(rv$processed_data, ncol = input$facet_ncol)
            }
        })
        
        # 使用标准化的容器和绘图函数
        render_plot_container(output, session$ns, input)
        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        # 使用标准化的文件命名函数
        filename_base <- reactive({
            if (input$mode == "single") {
                generate_filename("VK", input$sample)
            } else {
                generate_filename("VK", "Facet")
            }
        })

        setup_download_handlers(output, input, plot_reactive, filename_base)
    })
}
