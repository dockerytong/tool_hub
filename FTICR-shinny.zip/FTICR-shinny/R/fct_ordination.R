# ==============================================================================
# fct_ordination.R - 排序分析核心函数
# ==============================================================================

#' 计算排序分析 (PCA, PCoA, NMDS, RDA, CCA)
#' @param df DOM 数据 (长格式)
#' @param method 方法: "pca", "pcoa", "nmds", "rda", "cca"
#' @param dist_method 距离算法 (仅用于 pcoa, nmds)
#' @param env_df 环境因子数据框 (仅用于 rda, cca), 第一列必须是 Sample
calculate_ordination <- function(df, method = "pca", dist_method = "bray", env_df = NULL) {
    # 1. 数据准备：转宽格式
    mat_wide <- df %>%
        dplyr::select(Sample, Formula, Abundance) %>%
        tidyr::pivot_wider(names_from = Formula, values_from = Abundance, values_fill = 0) %>%
        tibble::column_to_rownames("Sample") %>%
        as.matrix()

    # 2. 数据预处理 (Hellinger 转化，推荐用于 PCA/RDA)
    if (method %in% c("pca", "rda")) {
        mat_wide <- vegan::decostand(mat_wide, method = "hellinger")
    }

    # 3. 环境因子对齐 (仅 RDA/CCA)
    env_mat <- NULL
    if (method %in% c("rda", "cca")) {
        if (is.null(env_df)) stop("RDA/CCA 需要上传环境因子数据")

        # 确保环境因子第一列是 Sample
        colnames(env_df)[1] <- "Sample"

        # 取交集样品
        common_samples <- intersect(rownames(mat_wide), env_df$Sample)
        if (length(common_samples) < 3) stop("DOM 数据与环境因子数据的共有样品少于 3 个")

        mat_wide <- mat_wide[common_samples, ]
        env_mat <- env_df %>%
            dplyr::filter(Sample %in% common_samples) %>%
            tibble::column_to_rownames("Sample")

        # 移除包含 NA 的环境因子列或行
        env_mat <- na.omit(env_mat)
        # 再次对齐，防止 na.omit 删除了行
        mat_wide <- mat_wide[rownames(env_mat), ]
    }

    # 4. 核心计算
    res_obj <- NULL
    points <- NULL
    vectors <- NULL
    eig_pct <- c(0, 0)
    stats_text <- ""

    tryCatch(
        {
            if (method == "pca") {
                res_obj <- vegan::rda(mat_wide) # vegan 中 rda(X) 等同于 PCA
                sum_res <- summary(res_obj)
                points <- as.data.frame(sum_res$sites[, 1:2])
                eig_pct <- round(sum_res$cont$importance[2, 1:2] * 100, 1)
            } else if (method == "pcoa") {
                dist_mat <- vegan::vegdist(mat_wide, method = dist_method)
                res_obj <- cmdscale(dist_mat, k = 2, eig = TRUE)
                points <- as.data.frame(res_obj$points)
                colnames(points) <- c("Axis1", "Axis2")
                eig_vals <- res_obj$eig[res_obj$eig > 0]
                eig_pct <- round(eig_vals[1:2] / sum(eig_vals) * 100, 1)
            } else if (method == "nmds") {
                # metaMDS 自动尝试多次寻找最优解
                res_obj <- vegan::metaMDS(mat_wide, distance = dist_method, k = 2, trymax = 20, trace = 0)
                points <- as.data.frame(res_obj$points)
                colnames(points) <- c("Axis1", "Axis2")
                stats_text <- paste("Stress =", round(res_obj$stress, 4))
            } else if (method == "rda") {
                res_obj <- vegan::rda(mat_wide ~ ., data = env_mat)
                sum_res <- summary(res_obj)
                points <- as.data.frame(sum_res$sites[, 1:2])
                # 提取环境因子箭头坐标
                vectors <- as.data.frame(sum_res$biplot[, 1:2]) %>%
                    tibble::rownames_to_column("Label")
                eig_pct <- round(sum_res$cont$importance[2, 1:2] * 100, 1)
                # 计算显著性 (耗时，仅计算整体)
                perm_test <- vegan::anova.cca(res_obj, permutations = 199)
                stats_text <- paste(
                    "Model p-value =", perm_test$`Pr(>F)`[1],
                    "| R2_adj =", round(vegan::RsquareAdj(res_obj)$adj.r.squared, 3)
                )
            } else if (method == "cca") {
                res_obj <- vegan::cca(mat_wide ~ ., data = env_mat)
                sum_res <- summary(res_obj)
                points <- as.data.frame(sum_res$sites[, 1:2])
                vectors <- as.data.frame(sum_res$biplot[, 1:2]) %>%
                    tibble::rownames_to_column("Label")
                eig_pct <- round(sum_res$cont$importance[2, 1:2] * 100, 1)
                perm_test <- vegan::anova.cca(res_obj, permutations = 199)
                stats_text <- paste("Model p-value =", perm_test$`Pr(>F)`[1])
            }

            # 统一列名
            colnames(points) <- c("Axis1", "Axis2")
            points <- points %>% tibble::rownames_to_column("Sample")
        },
        error = function(e) {
            stop(paste("计算错误:", e$message))
        }
    )

    list(
        points = points,
        vectors = vectors,
        eig_pct = eig_pct,
        stats = stats_text,
        method = toupper(method)
    )
}

#' 绘制排序图
plot_ordination <- function(ord_res, metadata = NULL, show_ellipse = FALSE) {
    points_df <- ord_res$points
    vectors_df <- ord_res$vectors

    # 合并分组
    if (!is.null(metadata)) {
        if (!"Sample" %in% colnames(metadata)) colnames(metadata)[1] <- "Sample"
        if (ncol(metadata) >= 2 && !"Group" %in% colnames(metadata)) colnames(metadata)[2] <- "Group"
        points_df <- points_df %>%
            dplyr::left_join(metadata, by = "Sample") %>%
            dplyr::mutate(Group = as.factor(tidyr::replace_na(as.character(Group), "Ungrouped")))
    } else {
        points_df$Group <- "All"
    }

    # 轴标签
    x_lab <- if (ord_res$method == "NMDS") "NMDS1" else paste0(ord_res$method, "1 (", ord_res$eig_pct[1], "%)")
    y_lab <- if (ord_res$method == "NMDS") "NMDS2" else paste0(ord_res$method, "2 (", ord_res$eig_pct[2], "%)")

    # 基础绘图
    p <- ggplot2::ggplot(points_df, ggplot2::aes(x = Axis1, y = Axis2)) +
        ggplot2::geom_hline(yintercept = 0, linetype = "dashed", color = "grey80") +
        ggplot2::geom_vline(xintercept = 0, linetype = "dashed", color = "grey80")

    # 绘制点和椭圆
    if (!is.null(metadata)) {
        p <- p + ggplot2::geom_point(ggplot2::aes(fill = Group), shape = 21, size = 4, color = "black")

        if (show_ellipse) {
            group_counts <- table(points_df$Group)
            valid_groups <- names(group_counts[group_counts >= 3])
            if (length(valid_groups) > 0) {
                p <- p + ggplot2::stat_ellipse(
                    data = points_df %>% dplyr::filter(Group %in% valid_groups),
                    ggplot2::aes(color = Group, fill = Group),
                    geom = "polygon", alpha = 0.1, show.legend = FALSE
                )
            }
        }
    } else {
        p <- p + ggplot2::geom_point(fill = "steelblue", shape = 21, size = 4, color = "black")
    }

    # 绘制环境因子箭头 (RDA/CCA)
    if (!is.null(vectors_df)) {
        # 缩放箭头以适应图形
        # 简单的自动缩放逻辑
        ratio <- max(abs(c(points_df$Axis1, points_df$Axis2))) / max(abs(c(vectors_df$Axis1, vectors_df$Axis2))) * 0.8
        vectors_df$Axis1 <- vectors_df$Axis1 * ratio
        vectors_df$Axis2 <- vectors_df$Axis2 * ratio

        p <- p +
            ggplot2::geom_segment(
                data = vectors_df, ggplot2::aes(x = 0, y = 0, xend = Axis1, yend = Axis2),
                arrow = ggplot2::arrow(length = ggplot2::unit(0.2, "cm")), color = "red", linewidth = 0.8
            ) +
            ggrepel::geom_text_repel(
                data = vectors_df, ggplot2::aes(x = Axis1, y = Axis2, label = Label),
                color = "red", fontface = "bold"
            )
    }

    # 标签和主题
    subtitle <- ord_res$stats
    p <- p +
        ggrepel::geom_text_repel(ggplot2::aes(label = Sample), size = 3, max.overlaps = 20) +
        ggplot2::labs(title = paste(ord_res$method, "Ordination"), subtitle = subtitle, x = x_lab, y = y_lab) +
        cowplot::theme_half_open(font_size = 12)

    return(p)
}
