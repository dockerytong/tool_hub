# ==============================================================================
# mod_upset.R - UpSet 模块 (完整版)
# ==============================================================================

mod_upset_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "UpSet 图",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                numericInput(ns("n_inter"), "最大交集数", value = 30, min = 10, max = 60),
                numericInput(ns("min_size"), "最小交集大小", value = 5, min = 1, max = 50),
                ui_display_settings(ns, default_w = 900, default_h = 600), # 新增
                ui_export_settings(ns, default_w = 12, default_h = 8)
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),

                # ---- 新增：解释文本 ----
                div(
                    class = "alert alert-info", style = "margin-top: 20px;",
                    h5(icon("info-circle"), "如何阅读 UpSet 图："),
                    tags$ul(
                        tags$li("UpSet 图是 Venn 图的高级替代品，适合展示多组样品间的交集。"),
                        tags$li(strong("左侧条形图 (Set Size):"), " 每个样品中检测到的分子总数。"),
                        tags$li(strong("中间矩阵点阵:"), " 黑色连线代表样品的组合（交集）。例如，如果 Sample1 和 Sample2 对应的点是黑色的且连在一起，代表这一列展示的是这两个样品共有的分子。"),
                        tags$li(strong("顶部条形图 (Intersection Size):"), " 对应交集组合中的分子数量。颜色代表这些分子的化学类别分布。")
                    )
                )
            )
        )
    )
}

mod_upset_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        plot_reactive <- reactive({
            req(rv$processed_data)
            samples <- unique(rv$processed_data$Sample)
            if (length(samples) < 2) {
                return(NULL)
            }
            plot_upset(rv$processed_data, samples, n_intersections = input$n_inter, min_size = input$min_size)
        })
        render_plot_container(output, session$ns, input)

        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )
        setup_download_handlers(output, input, plot_reactive, "UpSet")
    })
}
