# ==============================================================================
# mod_gibbs.R - Gibbs 能量模块 (完整版)
# ==============================================================================

mod_gibbs_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "Gibbs 能量",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                ui_display_settings(ns, default_w = 800, default_h = 600),
                ui_export_settings(ns, default_w = 10, default_h = 6)
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),
                uiOutput(ns("info_panel"))
            )
        )
    )
}

mod_gibbs_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        # 标准化的响应式逻辑
        plot_reactive <- reactive({
            req(rv$processed_data)
            if (!validate_sufficient_data(rv$processed_data, 1, "Gibbs能量分析")) {
                return(NULL)
            }
            plot_gibbs_distribution(rv$processed_data)
        })
        
        # 使用标准化的容器和绘图函数
        render_plot_container(output, session$ns, input)
        output$plot <- render_safe_plot(plot_reactive, 
            width_func = function() input$disp_w, 
            height_func = function() input$disp_h)
        
        # 标准化的分析信息面板
        output$info_panel <- renderUI({
            req(rv$processed_data)
            
            info_items <- list(
                list(label = "热力学解释:", 
                     description = "ΔG°Cox (Gibbs Free Energy of Carbon Oxidation) 反映有机质被微生物氧化分解的热力学势垒"),
                list(label = "高 Gibbs 值 (> 75 kJ/mol):", 
                     description = "热力学不稳定，更容易被微生物利用（Labile）"),
                list(label = "低 Gibbs 值:", 
                     description = "热力学稳定，通常对应氧化程度较高或芳香性较强的物质，较难降解（Recalcitrant）")
            )
            
            ui_analysis_info_panel(session$ns, "热力学解释", info_items, icon = "info-circle")
        })
        
        # 使用标准化的文件命名
        filename_base <- reactive({
            generate_filename("Gibbs", "Distribution")
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)
    })
}
