# ==============================================================================
# mod_export.R - 数据导出模块
# ==============================================================================

mod_export_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "数据导出",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                h5("导出汇总数据"),
                downloadButton(ns("download_formula"), "分子式汇总表"),
                downloadButton(ns("download_sample"), "样品汇总表"),
                hr(),
                h5("导出原始处理数据"),
                downloadButton(ns("download_full"), "完整数据表")
            ),
            mainPanel(
                width = 9,
                h4("分子式汇总预览"),
                tableOutput(ns("formula_preview")),
                hr(),
                h4("样品汇总预览"),
                tableOutput(ns("sample_preview"))
            )
        )
    )
}

mod_export_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        output$formula_preview <- renderTable({
            req(rv$export_data)
            rv$export_data$formula %>%
                head(10) %>%
                dplyr::mutate(across(where(is.numeric), ~ round(.x, 3)))
        })

        output$sample_preview <- renderTable({
            req(rv$export_data)
            rv$export_data$sample %>%
                dplyr::mutate(across(where(is.numeric), ~ round(.x, 3)))
        })

        output$download_formula <- downloadHandler(
            filename = function() "Formula_Summary.csv",
            content = function(file) readr::write_csv(rv$export_data$formula, file)
        )

        output$download_sample <- downloadHandler(
            filename = function() "Sample_Summary.csv",
            content = function(file) readr::write_csv(rv$export_data$sample, file)
        )

        output$download_full <- downloadHandler(
            filename = function() "Full_Processed_Data.csv",
            content = function(file) readr::write_csv(rv$processed_data, file)
        )
    })
}
