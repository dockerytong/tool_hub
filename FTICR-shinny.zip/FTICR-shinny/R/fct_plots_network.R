# ==============================================================================
# fct_plots_network.R - 网络分析可视化函数
# ==============================================================================

#' 绘制网络图
#' @description 使用visNetwork创建交互式网络图
#' @param network_data 网络数据
#' @param pagerank_result PageRank结果
#' @param node_size_scale 节点大小缩放因子
#' @param node_color_var 节点颜色变量（"pagerank"或"intensity"）
#' @return visNetwork对象
plot_network_graph <- function(network_data, pagerank_result, node_size_scale = 20, node_color_var = "pagerank") {
  if (!requireNamespace("visNetwork", quietly = TRUE)) {
    stop("需要安装visNetwork包")
  }

  # 合并节点数据
  nodes <- network_data$nodes %>%
    dplyr::left_join(pagerank_result, by = "formula") %>%
    dplyr::mutate(
      # 节点大小基于PageRank或强度
      size = case_when(
        node_color_var == "pagerank" ~ sqrt(pagerank) * node_size_scale,
        node_color_var == "intensity" ~ sqrt(intensity) * node_size_scale,
        TRUE ~ 10
      ),
      # 节点颜色
      color = case_when(
        node_color_var == "pagerank" ~ colorRampPalette(c("lightblue", "darkblue"))(100)[
          as.numeric(cut(pagerank, breaks = 100))
        ],
        node_color_var == "intensity" ~ colorRampPalette(c("lightgreen", "darkgreen"))(100)[
          as.numeric(cut(intensity, breaks = 100))
        ],
        TRUE ~ "lightblue"
      ),
      # 标签
      label = formula,
      # 标题（悬停显示）
      title = paste0(
        "Formula: ", formula, "\n",
        "Mass: ", round(mass, 4), "\n",
        "PageRank: ", round(pagerank, 4), "\n",
        "Intensity: ", round(intensity, 2)
      )
    )

  # 边数据
  edges <- network_data$edges %>%
    dplyr::mutate(
      # 边的标签
      label = reaction,
      # 边的标题
      title = paste0(
        "Reaction: ", reaction, "\n",
        "Mass diff: ", round(mass_diff, 4)
      ),
      # 边的颜色（根据反应类型）
      color = case_when(
        reaction %in% c("methylation", "demethylation") ~ "green",
        reaction %in% c("oxidation", "reduction") ~ "red",
        reaction %in% c("hydration", "dehydration") ~ "blue",
        reaction %in% c("decarboxylation", "carboxylation") ~ "orange",
        TRUE ~ "gray"
      )
    )

  # 创建网络图
  visNetwork::visNetwork(
    nodes = nodes,
    edges = edges,
    width = "100%",
    height = "600px"
  ) %>%
    visNetwork::visNodes(
      shape = "dot",
      font = list(size = 12, color = "black"),
      borderWidth = 2,
      shadow = TRUE
    ) %>%
    visNetwork::visEdges(
      arrows = list(to = list(enabled = TRUE, scaleFactor = 0.5)),
      smooth = list(type = "curvedCW", roundness = 0.2),
      shadow = TRUE
    ) %>%
    visNetwork::visLayout(randomSeed = 42) %>%
    visNetwork::visPhysics(
      solver = "forceAtlas2Based",
      forceAtlas2Based = list(
        gravitationalConstant = -50,
        centralGravity = 0.01,
        springLength = 100,
        springConstant = 0.08,
        damping = 0.4,
        avoidOverlap = 1
      )
    ) %>%
    visNetwork::visInteraction(
      hover = TRUE,
      tooltipDelay = 200,
      hideEdgesOnDrag = TRUE
    )
}

#' 绘制PageRank分布图
#' @description 显示PageRank值的分布
#' @param pagerank_result PageRank结果
#' @return ggplot对象
plot_pagerank_distribution <- function(pagerank_result) {
  ggplot2::ggplot(pagerank_result, ggplot2::aes(x = pagerank)) +
    ggplot2::geom_histogram(bins = 50, fill = "steelblue", alpha = 0.7) +
    ggplot2::geom_vline(
      xintercept = mean(pagerank_result$pagerank),
      linetype = "dashed",
      color = "red",
      size = 1
    ) +
    ggplot2::labs(
      title = "PageRank Distribution",
      x = "PageRank Value",
      y = "Count"
    ) +
    cowplot::theme_half_open(font_size = 12)
}

#' 绘制PageRank与强度相关性图
#' @description 显示PageRank与原始强度的关系
#' @param pagerank_result PageRank结果
#' @return ggplot对象
plot_pagerank_vs_intensity <- function(pagerank_result) {
  corr_coef <- cor(pagerank_result$pagerank, pagerank_result$intensity, method = "spearman")

  ggplot2::ggplot(pagerank_result, ggplot2::aes(x = intensity, y = pagerank)) +
    ggplot2::geom_point(alpha = 0.6, color = "darkblue") +
    ggplot2::geom_smooth(method = "loess", se = TRUE, color = "red", alpha = 0.3) +
    ggplot2::labs(
      title = paste("PageRank vs Intensity (Spearman ρ =", round(corr_coef, 3), ")"),
      x = "Intensity",
      y = "PageRank"
    ) +
    cowplot::theme_half_open(font_size = 12) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(size = 12)
    )
}

#' 绘制关键分子条形图
#' @description 显示Top N关键分子及其PageRank值
#' @param key_molecules 关键分子数据
#' @param top_n 显示前N个
#' @return ggplot对象
plot_key_molecules <- function(key_molecules, top_n = 10) {
  plot_data <- key_molecules %>%
    dplyr::slice(1:top_n) %>%
    dplyr::mutate(formula = factor(formula, levels = rev(formula)))

  ggplot2::ggplot(plot_data, ggplot2::aes(x = formula, y = pagerank)) +
    ggplot2::geom_col(fill = "steelblue", alpha = 0.8) +
    ggplot2::coord_flip() +
    ggplot2::labs(
      title = paste("Top", top_n, "Key Molecules by PageRank"),
      x = "Formula",
      y = "PageRank"
    ) +
    cowplot::theme_half_open(font_size = 12)
}

#' 绘制网络属性总结图
#' @description 显示网络的基本统计信息
#' @param network_properties 网络属性
#' @return ggplot对象列表
plot_network_summary <- function(network_properties) {
  summary_df <- network_properties$summary
  reaction_stats <- network_properties$reaction_stats

  # 网络基本属性图
  p1 <- ggplot2::ggplot(summary_df, ggplot2::aes(x = factor(1), y = n_nodes)) +
    ggplot2::geom_col(fill = "lightblue") +
    ggplot2::labs(title = "Number of Nodes", x = NULL, y = "Count") +
    cowplot::theme_half_open(font_size = 10)

  p2 <- ggplot2::ggplot(summary_df, ggplot2::aes(x = factor(1), y = n_edges)) +
    ggplot2::geom_col(fill = "lightgreen") +
    ggplot2::labs(title = "Number of Edges", x = NULL, y = "Count") +
    cowplot::theme_half_open(font_size = 10)

  p3 <- ggplot2::ggplot(summary_df, ggplot2::aes(x = factor(1), y = density)) +
    ggplot2::geom_col(fill = "lightcoral") +
    ggplot2::labs(title = "Network Density", x = NULL, y = "Density") +
    cowplot::theme_half_open(font_size = 10)

  # 反应类型统计图
  p4 <- ggplot2::ggplot(reaction_stats, ggplot2::aes(x = reorder(reaction, count), y = count)) +
    ggplot2::geom_col(fill = "steelblue", alpha = 0.8) +
    ggplot2::coord_flip() +
    ggplot2::labs(title = "Reaction Types", x = "Reaction", y = "Count") +
    cowplot::theme_half_open(font_size = 10)

  list(p1 = p1, p2 = p2, p3 = p3, p4 = p4)
}

#' 绘制度分布图
#' @description 显示网络的度分布
#' @param network_properties 网络属性
#' @return ggplot对象
plot_degree_distribution <- function(network_properties) {
  node_stats <- network_properties$node_stats

  ggplot2::ggplot(node_stats, ggplot2::aes(x = total_degree)) +
    ggplot2::geom_histogram(bins = 30, fill = "darkgreen", alpha = 0.7) +
    ggplot2::labs(
      title = "Node Degree Distribution",
      x = "Total Degree",
      y = "Count"
    ) +
    cowplot::theme_half_open(font_size = 12)
}

#' 绘制网络模块图
#' @description 显示网络模块（如果可用）
#' @param network_data 网络数据
#' @param modules 模块数据
#' @return visNetwork对象
plot_network_modules <- function(network_data, modules) {
  if (is.null(modules) || nrow(modules) == 0) {
    return(NULL)
  }

  # 合并模块信息
  nodes <- network_data$nodes %>%
    dplyr::left_join(modules, by = "formula") %>%
    dplyr::mutate(
      group = factor(module),
      # 为不同模块分配颜色
      color = colorRampPalette(RColorBrewer::brewer.pal(9, "Set3"))(n_distinct(module))[module]
    )

  # 创建模块网络图
  visNetwork::visNetwork(
    nodes = nodes %>% dplyr::select(id, label = formula, group, color, size = 10),
    edges = network_data$edges %>% dplyr::select(from, to, label = reaction),
    width = "100%",
    height = "600px"
  ) %>%
    visNetwork::visNodes(
      shape = "dot",
      font = list(size = 12),
      borderWidth = 2
    ) %>%
    visNetwork::visGroups(
      groupname = unique(nodes$group),
      color = unique(nodes$color)
    )
}

#' 绘制相关性热图
#' @description 显示各种网络指标之间的相关性
#' @param pagerank_result PageRank结果
#' @param network_properties 网络属性
#' @return ggplot对象
plot_correlation_heatmap <- function(pagerank_result, network_properties) {
  # 合并数据
  combined_data <- pagerank_result %>%
    dplyr::left_join(
      network_properties$node_stats %>% dplyr::select(formula, total_degree),
      by = "formula"
    )

  # 计算相关矩阵
  corr_matrix <- cor(
    combined_data %>% dplyr::select(pagerank, intensity, mass, total_degree),
    method = "spearman"
  )

  # 转换为长格式
  corr_df <- as.data.frame(as.table(corr_matrix))
  colnames(corr_df) <- c("Var1", "Var2", "value")

  ggplot2::ggplot(corr_df, ggplot2::aes(x = Var1, y = Var2, fill = value)) +
    ggplot2::geom_tile() +
    ggplot2::geom_text(ggplot2::aes(label = round(value, 2)), color = "white", size = 4) +
    ggplot2::scale_fill_gradient2(
      low = "darkblue",
      high = "darkred",
      mid = "white",
      midpoint = 0,
      limit = c(-1, 1)
    ) +
    ggplot2::labs(title = "Network Metrics Correlation Matrix") +
    cowplot::theme_half_open(font_size = 12) +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 1)
    )
}

#' 绘制网络演化图
#' @description 显示不同样品间网络的变化（需要多个样品数据）
#' @param network_results_list 多个样品的网络结果列表
#' @return ggplot对象
plot_network_evolution <- function(network_results_list) {
  # 提取每个网络的关键指标
  evolution_data <- do.call(rbind, lapply(names(network_results_list), function(sample) {
    res <- network_results_list[[sample]]
    data.frame(
      sample = sample,
      n_nodes = res$properties$summary$n_nodes,
      n_edges = res$properties$summary$n_edges,
      density = res$properties$summary$density,
      avg_pagerank = mean(res$pagerank$pagerank),
      max_pagerank = max(res$pagerank$pagerank),
      stringsAsFactors = FALSE
    )
  }))

  # 创建多面板图
  p1 <- ggplot2::ggplot(evolution_data, ggplot2::aes(x = sample, y = n_nodes)) +
    ggplot2::geom_line(color = "blue") +
    ggplot2::geom_point(color = "blue", size = 3) +
    ggplot2::labs(title = "Nodes Evolution", x = "Sample", y = "Node Count") +
    cowplot::theme_half_open(font_size = 10)

  p2 <- ggplot2::ggplot(evolution_data, ggplot2::aes(x = sample, y = n_edges)) +
    ggplot2::geom_line(color = "green") +
    ggplot2::geom_point(color = "green", size = 3) +
    ggplot2::labs(title = "Edges Evolution", x = "Sample", y = "Edge Count") +
    cowplot::theme_half_open(font_size = 10)

  p3 <- ggplot2::ggplot(evolution_data, ggplot2::aes(x = sample, y = density)) +
    ggplot2::geom_line(color = "red") +
    ggplot2::geom_point(color = "red", size = 3) +
    ggplot2::labs(title = "Density Evolution", x = "Sample", y = "Density") +
    cowplot::theme_half_open(font_size = 10)

  list(p1 = p1, p2 = p2, p3 = p3)
}