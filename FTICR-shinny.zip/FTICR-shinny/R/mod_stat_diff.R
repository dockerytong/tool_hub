# ==============================================================================
# mod_stat_diff.R - 统计差异分析模块 (完整版)
# ==============================================================================

mod_stat_diff_ui <- function(id) {
    ns <- NS(id)

    tabPanel(
        "统计差异",
        sidebarLayout(
            sidebarPanel(
                width = 3,
                h5("两组比较设置"),
                uiOutput(ns("group_a_selector")),
                uiOutput(ns("group_b_selector")),
                selectInput(ns("test_method"), "检验方法：", choices = c("Wilcoxon" = "wilcox", "t-test" = "t.test")),
                actionButton(ns("btn_run"), "开始计算", class = "btn-danger", icon = icon("fire")),
                hr(),
                h5("统计阈值设置"),
                numericInput(ns("p_threshold"), "P值阈值:", value = 0.05, min = 0, max = 1, step = 0.001),
                numericInput(ns("fc_threshold"), "差异倍数阈值 (log2):", value = 1, min = 0, max = 5, step = 0.1),
                helpText("差异倍数阈值以log2形式表示。例如，值为1表示2倍差异，值为2表示4倍差异。"),
                hr(),
                radioButtons(ns("plot_type"), "图表类型：", choices = c("火山图" = "volcano", "差异VK图" = "vk"), selected = "volcano"),
                ui_display_settings(ns, default_w = 900, default_h = 600), # 新增
                ui_export_settings(ns, default_w = 8, default_h = 6),
                hr(),
                downloadButton(ns("download_csv"), "下载结果表")
            ),
            mainPanel(
                width = 9,
                uiOutput(ns("plot_container")),

                # ---- 新增：解释文本 ----
                div(
                    class = "alert alert-info", style = "margin-top: 20px;",
                    h5(icon("info-circle"), "统计说明："),
                    tags$ul(
                        tags$li(strong("Volcano Plot (火山图):"), " 横轴为 Log2 Fold Change (差异倍数)，纵轴为 -Log10 P-value (显著性)。"),
                        tags$li("红色点代表在 Group A 中显著上调的分子，蓝色点代表在 Group B 中显著上调的分子。"),
                        tags$li(strong("差异 VK 图:"), " 将显著差异分子投射到 Van Krevelen 图上，可以直观地看到哪类化学物质（如木质素、蛋白质）在某组中富集。"),
                        tags$li("当前阈值由用户设置：P < ", tags$span(style = "font-weight: bold;", textOutput(ns("current_p_threshold"), inline = TRUE)), " 且 |Log2FC| > ", tags$span(style = "font-weight: bold;", textOutput(ns("current_fc_threshold"), inline = TRUE)), "。")
                    )
                ),
                hr(),
                h5("显著差异统计"),
                tableOutput(ns("stat_summary"))
            )
        )
    )
}

mod_stat_diff_server <- function(id, rv) {
    moduleServer(id, function(input, output, session) {
        ns <- session$ns

        output$group_a_selector <- renderUI({
            req(rv$processed_data)
            selectInput(ns("group_a"), "Group A (实验组):", choices = unique(rv$processed_data$Sample), multiple = TRUE)
        })

        output$group_b_selector <- renderUI({
            req(rv$processed_data)
            selectInput(ns("group_b"), "Group B (对照组):", choices = unique(rv$processed_data$Sample), multiple = TRUE)
        })

        stat_res <- reactiveVal(NULL)

        observeEvent(input$btn_run, {
            req(rv$processed_data, input$group_a, input$group_b, input$p_threshold, input$fc_threshold)
            if (length(input$group_a) < 2 || length(input$group_b) < 2) {
                showNotification("每组至少需要 2 个样品才能进行统计检验", type = "warning")
                return()
            }
            withProgress(message = "正在进行统计检验...", {
                res <- calculate_stat_diff(
                    rv$processed_data,
                    input$group_a,
                    input$group_b,
                    method = input$test_method,
                    p_threshold = input$p_threshold,
                    fc_threshold = input$fc_threshold
                )
                stat_res(res)
            })
        })

        plot_reactive <- reactive({
            req(stat_res())
            if (input$plot_type == "volcano") {
                plot_volcano(stat_res(), "Group A", "Group B")
            } else {
                plot_stat_vk(stat_res())
            }
        })

        render_plot_container(output, session$ns, input)

        output$plot <- render_safe_plot(plot_reactive,
            width_func = function() input$disp_w,
            height_func = function() input$disp_h
        )

        output$stat_summary <- renderTable({
            req(stat_res())
            stat_res() %>%
                dplyr::count(Significance) %>%
                dplyr::mutate(Percentage = round(n / sum(n) * 100, 1))
        })

        filename_base <- reactive({
            paste0("Stat_Diff_", input$plot_type)
        })
        setup_download_handlers(output, input, plot_reactive, filename_base)

        output$download_csv <- downloadHandler(
            filename = function() "Statistical_Difference.csv",
            content = function(file) readr::write_csv(stat_res(), file)
        )

        # 输出当前阈值显示
        output$current_p_threshold <- renderText({
            if(is.null(input$p_threshold)) "0.05" else format(input$p_threshold, nsmall = 3)
        })

        output$current_fc_threshold <- renderText({
            if(is.null(input$fc_threshold)) "1.0" else format(input$fc_threshold, nsmall = 1)
        })
    })
}
