# ==============================================================================
# mod_network.R - 分子网络分析模块
# ==============================================================================

#' 网络分析 UI
mod_network_ui <- function(id) {
  ns <- NS(id)

  tabPanel(
    "分子网络",
    # 确保visNetwork包已加载
    tags$head(
      tags$script(src = "https://cdnjs.cloudflare.com/ajax/libs/vis/4.21.0/vis.min.js"),
      tags$link(rel = "stylesheet", href = "https://cdnjs.cloudflare.com/ajax/libs/vis/4.21.0/vis.min.css")
    ),
    sidebarLayout(
      sidebarPanel(
        width = 3,
        # 网络构建参数
        h4("网络构建设置"),
        numericInput(
          ns("mass_tolerance"),
          "质量容差 (ppm):",
          value = 5,
          min = 1,
          max = 50,
          step = 1
        ),
        checkboxGroupInput(
          ns("reactions"),
          "选择反应类型:",
          choices = c(
            "脱羧/羧化" = "decarboxylation,carboxylation",
            "甲基化/去甲基化" = "methylation,demethylation",
            "氢化/脱氢" = "hydrogenation,dehydrogenation",
            "水合/脱水" = "hydration,dehydration",
            "氧化/还原" = "oxidation,reduction",
            "乙酰化" = "acetylation",
            "缩合" = "condensation",
            "羟基化/脱羟基" = "hydroxylation,dehydroxylation",
            "硝化/脱硝" = "nitration,denitration",
            "磺化/脱磺" = "sulfation,desulfation",
            "磷酸化/脱磷酸" = "phosphorylation,dephosphorylation"
          ),
          selected = c(
            "脱羧/羧化",
            "甲基化/去甲基化",
            "氢化/脱氢",
            "水合/脱水",
            "氧化/还原"
          )
        ),
        hr(),

        # 可视化选项
        h4("可视化设置"),
        radioButtons(
          ns("node_color"),
          "节点颜色:",
          choices = c(
            "PageRank值" = "pagerank",
            "强度" = "intensity",
            "模块" = "module"
          ),
          selected = "pagerank"
        ),
        sliderInput(
          ns("node_size"),
          "节点大小缩放:",
          value = 20,
          min = 5,
          max = 50,
          step = 5
        ),
        checkboxInput(
          ns("show_labels"),
          "显示分子式标签",
          value = FALSE
        ),
        hr(),

        # 分析选项
        h4("分析选项"),
        numericInput(
          ns("top_molecules"),
          "显示关键分子数:",
          value = 10,
          min = 5,
          max = 50,
          step = 5
        ),
        checkboxInput(
          ns("calc_modules"),
          "计算网络模块",
          value = TRUE
        ),
        hr(),

        # 导出设置
        downloadButton(ns("download_network"), "下载网络数据"),
        downloadButton(ns("download_pagerank"), "下载PageRank结果")
      ),
      mainPanel(
        width = 9,
        tabsetPanel(
          id = ns("network_tabs"),
          tabPanel(
            "网络图",
            br(),
            conditionalPanel(
              condition = "input.show_labels == false",
              ns = ns,
              p("提示：勾选'显示分子式标签'可在节点上显示公式", style = "color: #888; font-style: italic;")
            ),
            if (requireNamespace("visNetwork", quietly = TRUE)) {
              visNetworkOutput(ns("network_plot"), height = "700px")
            } else {
              div(
                class = "alert alert-warning",
                "需要安装visNetwork包才能显示网络图。请运行: install.packages('visNetwork')"
              )
            }
          ),
          tabPanel(
            "PageRank分析",
            fluidRow(
              column(6, plotOutput(ns("pagerank_dist"), height = "300px")),
              column(6, plotOutput(ns("pagerank_vs_intensity"), height = "300px"))
            ),
            br(),
            plotOutput(ns("key_molecules"), height = "400px"),
            br(),
            h4("Top 关键分子"),
            tableOutput(ns("top_molecules_table"))
          ),
          tabPanel(
            "网络统计",
            fluidRow(
              column(6, plotOutput(ns("network_summary1"), height = "250px")),
              column(6, plotOutput(ns("network_summary2"), height = "250px"))
            ),
            br(),
            fluidRow(
              column(6, plotOutput(ns("network_summary3"), height = "250px")),
              column(6, plotOutput(ns("reaction_stats"), height = "250px"))
            ),
            br(),
            plotOutput(ns("degree_dist"), height = "300px"),
            br(),
            h4("网络属性详情"),
            tableOutput(ns("network_properties_table"))
          ),
          tabPanel(
            "相关性分析",
            plotOutput(ns("correlation_heatmap"), height = "500px"),
            br(),
            h4("相关性系数"),
            tableOutput(ns("correlation_table"))
          ),
          tabPanel(
            "模块分析",
            conditionalPanel(
              condition = "output.has_modules",
              ns = ns,
              if (requireNamespace("visNetwork", quietly = TRUE)) {
                visNetworkOutput(ns("module_network"), height = "600px")
              } else {
                div(
                  class = "alert alert-warning",
                  "需要安装visNetwork包才能显示模块网络图。"
                )
              }
            ),
            conditionalPanel(
              condition = "!output.has_modules",
              ns = ns,
              p("模块分析需要安装igraph包", style = "color: red; font-weight: bold;")
            )
          )
        )
      )
    )
  )
}

#' 网络分析服务器逻辑
mod_network_server <- function(id, rv) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns

    # 网络分析结果
    network_result <- reactive({
      req(rv$processed_data)

      # 验证数据
      if (!validate_sufficient_data(rv$processed_data, 10, "网络分析")) {
        return(NULL)
      }

      # 解析选择的反应
      selected_reactions <- unlist(strsplit(input$reactions, ","))

      # 获取反应字典的子集
      reaction_dict <- get_reaction_dict()[selected_reactions]

      # 运行网络分析
      tryCatch({
        result <- run_network_analysis(
          rv$processed_data,
          reaction_dict = reaction_dict,
          mass_tolerance = input$mass_tolerance
        )
        result
      }, error = function(e) {
        showNotification(
          paste("网络分析失败:", e$message),
          type = "error",
          duration = 5
        )
        NULL
      })
    })

    # 网络图
    output$network_plot <- renderVisNetwork({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plot_network_graph(
        res$network,
        res$pagerank,
        node_size_scale = input$node_size,
        node_color_var = input$node_color
      )
    })

    # PageRank分布图
    output$pagerank_dist <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plot_pagerank_distribution(res$pagerank)
    }, res = 96)

    # PageRank vs 强度图
    output$pagerank_vs_intensity <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plot_pagerank_vs_intensity(res$pagerank)
    }, res = 96)

    # 关键分子图
    output$key_molecules <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plot_key_molecules(res$key_molecules, input$top_molecules)
    }, res = 96)

    # 关键分子表格
    output$top_molecules_table <- renderTable({
      res <- network_result()
      if (is.null(res)) return(NULL)

      res$key_molecules %>%
        dplyr::select(rank, formula, pagerank, intensity, intensity_rank) %>%
        dplyr::mutate(
          pagerank = round(pagerank, 4),
          intensity = round(intensity, 2)
        )
    }, striped = TRUE, hover = TRUE, bordered = TRUE)

    # 网络统计图1
    output$network_summary1 <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plots <- plot_network_summary(res$properties)
      plots$p1
    }, res = 96)

    # 网络统计图2
    output$network_summary2 <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plots <- plot_network_summary(res$properties)
      plots$p2
    }, res = 96)

    # 网络统计图3
    output$network_summary3 <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plots <- plot_network_summary(res$properties)
      plots$p3
    }, res = 96)

    # 反应统计图
    output$reaction_stats <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plots <- plot_network_summary(res$properties)
      plots$p4
    }, res = 96)

    # 度分布图
    output$degree_dist <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plot_degree_distribution(res$properties)
    }, res = 96)

    # 网络属性表格
    output$network_properties_table <- renderTable({
      res <- network_result()
      if (is.null(res)) return(NULL)

      res$properties$summary %>%
        tidyr::pivot_longer(everything(), names_to = "Property", values_to = "Value") %>%
        dplyr::mutate(Value = round(Value, 4))
    }, striped = TRUE, hover = TRUE, bordered = TRUE)

    # 相关性热图
    output$correlation_heatmap <- renderPlot({
      res <- network_result()
      if (is.null(res)) return(NULL)

      plot_correlation_heatmap(res$pagerank, res$properties)
    }, res = 96)

    # 相关性表格
    output$correlation_table <- renderTable({
      res <- network_result()
      if (is.null(res)) return(NULL)

      data.frame(
        Correlation = c("PageRank vs Intensity", "PageRank vs Mass"),
        Coefficient = round(c(res$correlations$pagerank_intensity, res$correlations$pagerank_mass), 4),
        Method = "Spearman"
      )
    }, striped = TRUE, hover = TRUE, bordered = TRUE)

    # 模块网络图
    output$module_network <- renderVisNetwork({
      res <- network_result()
      if (is.null(res) || is.null(res$modules)) return(NULL)

      # 合并模块信息
      nodes_with_modules <- res$network$nodes %>%
        dplyr::left_join(res$modules, by = "formula")

      # 创建模块网络
      plot_network_modules(res$network, res$modules)
    })

    # 是否有模块
    output$has_modules <- reactive({
      res <- network_result()
      !is.null(res) && !is.null(res$modules)
    })

    # 模块表格
    output$module_table <- renderTable({
      res <- network_result()
      if (is.null(res) || is.null(res$modules)) return(NULL)

      res$modules %>%
        dplyr::count(module) %>%
        dplyr::arrange(desc(n)) %>%
        dplyr::rename(
          Module = module,
          "Molecules Count" = n
        )
    }, striped = TRUE, hover = TRUE, bordered = TRUE)

    # 下载网络数据
    output$download_network <- downloadHandler(
      filename = function() paste0("network_analysis_", Sys.Date(), ".csv"),
      content = function(file) {
        res <- network_result()
        if (is.null(res)) return(NULL)

        # 合并网络数据
        network_df <- res$network$nodes %>%
          dplyr::left_join(res$network$edges %>% dplyr::select(from, reaction) %>% dplyr::group_by(from) %>% dplyr::summarise(n_reactions = n(), .groups = "drop"),
          by = c("id" = "from")
        ) %>%
          dplyr::left_join(res$pagerank, by = "formula") %>%
          dplyr::left_join(res$properties$node_stats %>% dplyr::select(formula, total_degree),
            by = "formula"
          )

        if (!is.null(res$modules)) {
          network_df <- network_df %>%
            dplyr::left_join(res$modules, by = "formula")
        }

        readr::write_csv(network_df, file)
      }
    )

    # 下载PageRank结果
    output$download_pagerank <- downloadHandler(
      filename = function() paste0("pagerank_results_", Sys.Date(), ".csv"),
      content = function(file) {
        res <- network_result()
        if (is.null(res)) return(NULL)

        readr::write_csv(res$pagerank, file)
      }
    )

    # 分析信息面板
    output$info_panel <- renderUI({
      info_items <- list(
        list(
          label = "PageRank算法:",
          description = "基于网络连接结构评估节点重要性，常用于网页排名"
        ),
        list(
          label = "反应网络:",
          description = "基于质量差识别可能的分子转化反应，构建有向网络"
        ),
        list(
          label = "关键分子:",
          description = "PageRank值高的分子在网络中具有重要地位，可能是转化枢纽"
        ),
        list(
          label = "网络模块:",
          description = "识别紧密连接的分子群组，反映功能相关的分子集合"
        )
      )

      ui_analysis_info_panel(session$ns, "网络分析说明", info_items, icon = "project-diagram")
    })
  })
}