# FTICR-shinny: FT-ICR MS DOM Analysis Tool

## Overview

FTICR-shinny is a comprehensive R Shiny web application for analyzing FT-ICR MS (Fourier Transform Ion Cyclotron Resonance Mass Spectrometry) data of dissolved organic matter (DOM). The application provides a user-friendly interface for processing, visualizing, and statistically analyzing complex mass spectrometry data, specifically designed for environmental chemistry research.

## Features

- **Data Upload**: Support for multiple CSV file uploads with TIC normalization and background subtraction
- **Van Krevelen Diagrams**: Interactive visualization of molecular composition
- **Diversity Analysis**: Alpha diversity metrics and comparisons
- **Chemical Composition**: Elemental composition analysis and ratios
- **Lability Assessment**: Classification of DOM into labile, intermediate, and recalcitrant fractions
- **CRAM Identification**: Detection of carboxylic-rich alicyclic molecules
- **Statistical Analysis**: Differential analysis, correlation analysis, and machine learning capabilities
- **Network Analysis**: Compound transformation networks
- **Export Functionality**: Multiple format support for results export

## Table of Contents

- [Installation](#installation)
- [Usage](#usage)
- [Modules](#modules)
- [Dependencies](#dependencies)
- [Contributing](#contributing)
- [License](#license)

## Installation

### Prerequisites

- R >= 4.0.0
- RStudio (optional but recommended)

### Setup

1. Clone or download the repository
```bash
git clone https://github.com/username/FTICR-shinny.git
cd FTICR-shinny
```

2. Install required R packages:
```r
# Install packages from CRAN
install.packages(c(
  "shiny",
  "tidyverse",
  "data.table",
  "vegan",
  "ggplot2", 
  "plotly",
  "ComplexUpset",
  "corrplot",
  "cowplot",
  "ggrepel",
  "readxl"
))
```

### Running the Application

To run the application locally:

```r
library(shiny)
setwd("path/to/FTICR-shinny")
runApp()
```

Or directly from R console:

```r
shiny::runApp("path/to/FTICR-shinny")
```

## Modules

The application is organized into 17 specialized modules:

### Data Processing
1. **Data Upload** (`mod_data_upload.R`) - File upload and preprocessing
2. **VK Plot** (`mod_vk_plot.R`) - Van Krevelen diagram visualization

### Analysis Modules
3. **Composition** (`mod_composition.R`) - Elemental composition analysis
4. **Diversity** (`mod_diversity.R`) - Alpha diversity calculations
5. **Ordination** (`mod_ordination.R`) - PCoA/NMDS analysis
6. **Molecular** (`mod_molecular.R`) - Molecular characteristics
7. **Properties** (`mod_properties.R`) - Chemical properties prediction
8. **Gibbs** (`mod_gibbs.R`) - Gibbs free energy calculations
9. **Lability** (`mod_lability.R`) - Biological lability classification
10. **CRAM** (`mod_cram.R`) - Carboxylic-rich alicyclic molecule identification
11. **Difference** (`mod_diff.R`) - Basic differential analysis
12. **Statistical Difference** (`mod_stat_diff.R`) - Advanced statistical analysis
13. **UpSet** (`mod_upset.R`) - Set relationship visualization
14. **Correlation** (`mod_correlation.R`) - Correlation analysis
15. **Transformation** (`mod_transformation.R`) - Compound transformation networks
16. **Machine Learning** (`mod_ml.R`) - Supervised/unsupervised learning
17. **Export** (`mod_export.R`) - Results export functionality

## Dependencies

### Core Dependencies
- `shiny` - Web application framework
- `tidyverse` - Data manipulation and analysis
- `data.table` - High-performance data processing
- `vegan` - Ecological statistics analysis
- `ggplot2` - Data visualization
- `plotly` - Interactive charts

### Specialized Packages
- `ComplexUpset` - Set visualization
- `corrplot` - Correlation matrix plots
- `cowplot` - Figure composition
- `ggrepel` - Label overlap handling
- `readxl` - Excel file reading

## Data Format

The application accepts CSV files with the following columns:
- `sum formula` - Molecular formula (e.g., C10H12O5)
- `Observed Intens` - Intensity/abundance value
- `C` - Carbon count
- `H` - Hydrogen count
- `N` - Nitrogen count
- `O` - Oxygen count
- `S` - Sulfur count

## Development

### Architecture

The application follows a modular design pattern with consistent naming conventions:

- **Naming Space Handling**: Use `session$ns` directly instead of redefining as `ns`
- **Reactive Logic**: Use `reactive()` consistently instead of mixing with `reactiveVal()`
- **Error Handling**: Standardized with validation functions
- **Function Calls**: Consistent parameters for common functions

### Adding New Modules

To add a new module:

1. Create new module file in `R/` directory following the naming pattern `mod_*.R`
2. Implement UI and Server functions with the standard signature
3. Add module to `app.R` in the UI and Server sections
4. Update documentation if necessary

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details on how to get started.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, please open an issue in the GitHub repository or contact the maintainers.