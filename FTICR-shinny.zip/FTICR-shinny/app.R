# ==============================================================================
# app.R - 主入口（完整版）
# ==============================================================================

source("global.R")

# ---- UI ----
ui <- navbarPage(
    title = "FT-ICR MS DOM 分析",
    id = "main_navbar",
    mod_data_upload_ui("upload"),
    mod_vk_plot_ui("vk"),
    mod_composition_ui("composition"),
    mod_diversity_ui("diversity"),
    mod_ordination_ui("ordination"),
    mod_molecular_ui("molecular"),
    mod_properties_ui("properties"),
    mod_gibbs_ui("gibbs"),
    mod_lability_ui("lability"),
    mod_cram_ui("cram"),
    mod_diff_ui("diff"),
    mod_stat_diff_ui("stat_diff"),
    mod_upset_ui("upset"),
    mod_correlation_ui("correlation"),
    mod_transformation_ui("transformation"),
    mod_ml_ui("ml"),
    mod_export_ui("export")
)

# ---- Server ----
server <- function(input, output, session) {
    # 共享数据
    rv <- reactiveValues(
        file_info = NULL,
        sample_names = NULL,
        processed_data = NULL,
        alpha_div = NULL,
        pcoa_result = NULL,
        wa_data = NULL,
        lability_result = NULL,
        cram_data = NULL,
        diff_result = NULL,
        env_data = NULL,
        cor_result = NULL,
        export_data = NULL
    )

    # 调用模块
    mod_data_upload_server("upload", rv)
    mod_vk_plot_server("vk", rv)
    mod_composition_server("composition", rv)
    mod_diversity_server("diversity", rv)
    mod_ordination_server("ordination", rv)
    mod_molecular_server("molecular", rv)
    mod_properties_server("properties", rv)
    mod_gibbs_server("gibbs", rv)
    mod_lability_server("lability", rv)
    mod_cram_server("cram", rv)
    mod_diff_server("diff", rv)
    mod_stat_diff_server("stat_diff", rv)
    mod_upset_server("upset", rv)
    mod_correlation_server("correlation", rv)
    mod_transformation_server("transformation", rv)
    mod_ml_server("ml", rv)
    mod_export_server("export", rv)
}

shinyApp(ui, server)
