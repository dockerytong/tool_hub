# ==============================================================================
# global.R - 全局配置与依赖加载
# ==============================================================================

# ---- 依赖包 ----
library(shiny)
library(tidyverse)
library(data.table)
library(cowplot)
library(vegan)
library(ggrepel)
library(ComplexUpset)
library(corrplot)
library(readxl)
library(igraph)
library(visNetwork)

# ---- 常量定义 ----
VK_ZONES <- tribble(
    ~Category,       ~xmin, ~xmax, ~ymin, ~ymax,
    "Lipid-like",    0.00,  0.30,  1.5,   2.0,
    "Protein-like",  0.30,  0.67,  1.5,   2.2,
    "Carboh.-like",  0.67,  1.20,  1.5,   2.2,
    "Lignin-like",   0.10,  0.67,  0.7,   1.5,
    "Tannin-like",   0.67,  1.20,  0.5,   1.5,
    "Cond. arom.",   0.00,  0.67,  0.2,   0.7,
    "Unsaturated",   0.00,  0.10,  0.7,   1.5
)

VK_COLORS <- c(
    "Lipid-like"    = "#E41A1C",
    "Protein-like"  = "#377EB8",
    "Carboh.-like"  = "#4DAF4A",
    "Lignin-like"   = "#984EA3",
    "Tannin-like"   = "#FF7F00",
    "Cond. arom."   = "#A65628",
    "Unsaturated"   = "#F781BF",
    "Other"         = "grey70"
)

ELEM_COLORS <- c(
    "CHO" = "#66c2a5", "CHON" = "#fc8d62",
    "CHOS" = "#8da0cb", "CHONS" = "#e78ac3"
)

LABILITY_COLORS <- c(
    "Labile" = "#2ca02c", "Intermediate" = "#ff7f0e", "Recalcitrant" = "#d62728"
)

CRAM_COLORS <- c("CRAM" = "#1f77b4", "Non-CRAM" = "#d3d3d3")

# ---- 加载函数文件 ----
source("R/utils_helpers.R")
source("R/fct_chemistry.R")
source("R/fct_ordination.R")
source("R/fct_plots.R")
source("R/fct_network.R")
source("R/fct_plots_network.R")

# ---- 加载模块 ----
module_files <- list.files("R", pattern = "^mod_", full.names = TRUE)
sapply(module_files, source)


# ---- 常见转化类型库 ----
TRANSFORMATIONS <- tibble::tribble(
    ~Name,           ~Formula, ~Mass,
    "Methylation",   "CH2",    14.01565,
    "Oxidation",     "O",      15.99491,
    "Hydrogenation", "H2",     2.01565,
    "Acetylation",   "C2H2O",  42.01056,
    "Carboxylation", "CO2",    43.98983,
    "Condensation",  "H2O",    18.01056,
    "Nitrogenation", "NH",     15.01090,
    "Desulfuration", "S",      31.97207
)
