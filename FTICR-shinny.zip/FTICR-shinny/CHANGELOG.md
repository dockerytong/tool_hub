# Changelog

All notable changes to the FTICR-shinny project will be documented in this file.

## [Unreleased]

### Added
- Initial project structure
- 17 specialized modules for DOM analysis
- Modular architecture with consistent naming conventions
- Comprehensive documentation

### Changed
- Standardized naming space handling using `session$ns` 
- Unified reactive logic using `reactive()` pattern
- Improved error handling and data validation
- Consistent file naming conventions
- Refactored modules for better maintainability

### Fixed
- Code inconsistencies across modules
- Mixed usage of reactiveVal and reactive patterns
- Inconsistent function call parameters
- UI component inconsistencies

## [1.0.0] - 2024-12-09

### Added
- Complete FT-ICR MS DOM analysis application
- Data upload and preprocessing capabilities
- Van Krevelen diagram visualization
- Diversity and composition analysis
- Statistical analysis modules
- Network analysis for compound transformations
- Machine learning capabilities
- Export functionality for results
- Comprehensive documentation and testing

[Unreleased]: https://github.com/username/FTICR-shinny/compare/v1.0.0...HEAD