#!/bin/bash

# Step 1: Login to GitHub CLI (you need to run this yourself)
# gh auth login

# Step 2: Create a private repository on GitHub
# gh repo create FTICR-shinny --private --description "FT-ICR MS DOM Analysis Tool - R Shiny application for analyzing dissolved organic matter"

# Alternatively, if using curl to create the repo via GitHub API:
# curl -L \
#   -X POST \
#   -H "Accept: application/vnd.github+json" \
#   -H "Authorization: Bearer YOUR_TOKEN_HERE" \
#   -H "X-GitHub-Api-Version: 2022-11-28" \
#   https://api.github.com/user/repos \
#   -d '{"name":"FTICR-shinny","private":true,"description":"FT-ICR MS DOM Analysis Tool - R Shiny application for analyzing dissolved organic matter"}'

# Step 3: Add the remote origin (replace with YOUR username)
# git remote add origin https://github.com/YOUR_USERNAME/FTICR-shinny.git

# Step 4: Push the code to the repository
# git branch -M main
# git push -u origin main

echo "To upload this project to a private GitHub repository, please follow these steps:"
echo ""
echo "1. Install GitHub CLI if not already installed:"
echo "   https://github.com/cli/cli#installation"
echo ""
echo "2. Authenticate with GitHub:"
echo "   gh auth login"
echo ""
echo "3. Create a private repository:"
echo "   gh repo create FTICR-shinny --private --description \"FT-ICR MS DOM Analysis Tool - R Shiny application for analyzing dissolved organic matter\""
echo ""
echo "4. Add the remote origin:"
echo "   git remote add origin https://github.com/YOUR_USERNAME/FTICR-shinny.git"
echo ""
echo "5. Push the code to GitHub:"
echo "   git branch -M main"
echo "   git push -u origin main"
echo ""
echo "Alternatively, you can create the repository manually on GitHub.com:"
echo "1. Go to https://github.com/new"
echo "2. Name the repository 'FTICR-shinny'"
echo "3. Select 'Private'"
echo "4. Do NOT initialize with a README (since you already have commits)"
echo "5. Copy the HTTPS URL"
echo "6. Run: git remote add origin PASTE_THE_URL_HERE"
echo "7. Run: git push -u origin main"