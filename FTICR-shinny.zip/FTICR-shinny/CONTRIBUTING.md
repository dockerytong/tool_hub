# Contributing to FTICR-shinny

Thank you for your interest in contributing to FTICR-shinny! We welcome contributions from the community and are excited to work with you to improve this tool for FT-ICR MS DOM analysis.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [Getting Started](#getting-started)
- [Development Workflow](#development-workflow)
- [Project Structure](#project-structure)
- [Coding Standards](#coding-standards)
- [Pull Request Process](#pull-request-process)
- [Reporting Issues](#reporting-issues)
- [Questions?](#questions)

## Code of Conduct

By participating in this project, you agree to abide by our [Code of Conduct](CODE_OF_CONDUCT.md). Please read it before contributing.

## Getting Started

### Prerequisites

- R >= 4.0.0
- RStudio (recommended)
- Git

### Setup

1. Fork the repository on GitHub
2. Clone your fork locally:
   ```bash
   git clone https://github.com/YOUR_USERNAME/FTICR-shinny.git
   cd FTICR-shinny
   ```
3. Install required R packages:
   ```r
   install.packages(c("shiny", "tidyverse", "data.table", "vegan", "ggplot2", 
                      "plotly", "ComplexUpset", "corrplot", "cowplot", "ggrepel", "readxl"))
   ```
4. Run the application to make sure everything works:
   ```r
   shiny::runApp()
   ```

## Development Workflow

### Branching Strategy

- `main` - Production-ready code
- `develop` - Integration branch for features
- Feature branches - Named descriptively (e.g., `feature/new-visualization-module`, `bugfix/vk-plot-crash`)

### Creating a Feature Branch

```bash
git checkout -b feature/your-feature-name
```

## Project Structure

```
FTICR-shinny/
├── app.R                    # Main application file
├── global.R                 # Global configuration and dependencies
├── R/                       # Modules and functions
│   ├── mod_*.R             # Shiny modules (UI + Server)
│   ├── fct_*.R             # Function files
│   └── utils_helpers.R     # Utility functions
├── test_all_modules.R      # Module testing script
├── README.md               # Project overview
├── LICENSE                 # License information
├── CHANGELOG.md            # Release notes
├── CONTRIBUTING.md         # This file
├── CODE_OF_CONDUCT.md      # Community guidelines
└── .gitignore             # Files to ignore
```

## Coding Standards

### R Code

- Follow the [Tidyverse Style Guide](https://style.tidyverse.org/)
- Use snake_case for variable and function names
- Limit line length to 80 characters where possible
- Include meaningful comments for complex logic

### Module Structure

Each module should follow the standard pattern:

```r
# UI Function
mod_module_name_ui <- function(id) {
  ns <- NS(id)
  # UI code here
}

# Server Function  
mod_module_name_server <- function(id, rv) {
  moduleServer(id, function(input, output, session) {
    # Module logic here
  })
}
```

### Naming Conventions

- Module files: `mod_功能名称.R` (e.g., `mod_data_upload.R`)
- Function files: `fct_功能类别.R` (e.g., `fct_chemistry.R`)
- Module functions: `mod_moduleName_ui()` and `mod_moduleName_server()`
- Naming Space: Use `session$ns` directly, avoid redefining as `ns`
- Reactive Logic: Use `reactive()` consistently

### Error Handling

- Implement standardized validation using helper functions
- Provide user-friendly error messages
- Use `withProgress()` for long-running operations

## Pull Request Process

1. Ensure your code follows the coding standards
2. Update documentation as needed
3. Test your changes thoroughly
4. Add tests for new functionality if applicable
5. Create your pull request from your feature branch to the `develop` branch
6. Fill out the pull request template with a clear description
7. Link any related issues
8. Wait for review and address feedback

### Pull Request Template

When creating a pull request, please include:

- **Summary**: Brief description of changes
- **Type**: Bug fix, enhancement, new feature, or documentation
- **Testing**: How changes were tested
- **Related Issues**: Closes #issue-number (if applicable)

## Reporting Issues

### Bug Reports

When reporting bugs, please include:

- R version and package versions
- Operating system
- Steps to reproduce
- Expected behavior vs actual behavior
- Any relevant error messages

### Feature Requests

For feature requests, please describe:

- The problem you're trying to solve
- Your proposed solution
- How it would benefit the project
- Any potential implementation details

## Questions?

If you have questions about contributing, feel free to:

- Open an issue for technical questions
- Email the maintainers (if contact info is available)
- Check the [documentation](DEVELOPMENT_DOCUMENTATION.md) for technical details

---

Thank you again for your interest in contributing! We appreciate your efforts to make FTICR-shinny better for the research community.